package com.traj.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "traj.db";
    private static final int DB_VER = 2;
    private final Context ctx;

    public DbHelper(Context ctx) { super(ctx, DB_NAME, null, DB_VER); this.ctx = ctx; }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE routes(" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "name TEXT," +
            "ts INTEGER," +
            "dur INTEGER," +
            "dist REAL," +
            "asc REAL," +
            "altOff REAL," +
            "origAltOff REAL," +
            "baseAlt REAL DEFAULT 0," +
            "gpsEnabled INTEGER DEFAULT 0," +
            "startLat REAL DEFAULT 0," +
            "startLon REAL DEFAULT 0," +
            "recordPrecision INTEGER DEFAULT 0," +
            "pts TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) {
        if (o < 2) {
            try { db.execSQL("ALTER TABLE routes ADD COLUMN baseAlt REAL DEFAULT 0"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE routes ADD COLUMN gpsEnabled INTEGER DEFAULT 0"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE routes ADD COLUMN startLat REAL DEFAULT 0"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE routes ADD COLUMN startLon REAL DEFAULT 0"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE routes ADD COLUMN recordPrecision INTEGER DEFAULT 0"); } catch (Exception ignored) {}
        }
    }

    public long insert(Route r) {
        ContentValues cv = new ContentValues();
        cv.put("name", r.name);
        cv.put("ts", r.timestamp);
        cv.put("dur", r.duration);
        cv.put("dist", r.totalDist);
        cv.put("asc", r.totalAsc);
        cv.put("altOff", r.altOff);
        cv.put("origAltOff", r.origAltOff);
        cv.put("baseAlt", r.baseAlt);
        cv.put("gpsEnabled", r.gpsEnabled ? 1 : 0);
        cv.put("startLat", r.startLat);
        cv.put("startLon", r.startLon);
        cv.put("recordPrecision", r.recordPrecision);
        cv.put("pts", ptsToJson(r.pts));
        return getWritableDatabase().insert("routes", null, cv);
    }

    public void update(Route r) {
        ContentValues cv = new ContentValues();
        cv.put("name", r.name);
        cv.put("altOff", r.altOff);
        cv.put("baseAlt", r.baseAlt);
        getWritableDatabase().update("routes", cv, "id=?", new String[]{String.valueOf(r.id)});
    }

    public void delete(long id) {
        getWritableDatabase().delete("routes", "id=?", new String[]{String.valueOf(id)});
    }

    public List<Route> getAll() {
        List<Route> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT id,name,ts,dur,dist,asc,altOff,origAltOff,baseAlt,gpsEnabled,startLat,startLon,recordPrecision,pts FROM routes ORDER BY id DESC", null);
        while (c.moveToNext()) {
            list.add(cursorToRoute(c));
        }
        c.close();
        return list;
    }

    public Route getById(long id) {
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT id,name,ts,dur,dist,asc,altOff,origAltOff,baseAlt,gpsEnabled,startLat,startLon,recordPrecision,pts FROM routes WHERE id=?",
            new String[]{String.valueOf(id)});
        Route r = null;
        if (c.moveToFirst()) r = cursorToRoute(c);
        c.close();
        return r;
    }

    private Route cursorToRoute(Cursor c) {
        Route r = new Route();
        r.id = c.getLong(0);
        r.name = c.getString(1);
        r.timestamp = c.getLong(2);
        r.duration = c.getLong(3);
        r.totalDist = c.getFloat(4);
        r.totalAsc = c.getFloat(5);
        r.altOff = c.getFloat(6);
        r.origAltOff = c.getFloat(7);
        r.baseAlt = c.getFloat(8);
        r.gpsEnabled = c.getInt(9) == 1;
        r.startLat = c.getFloat(10);
        r.startLon = c.getFloat(11);
        r.recordPrecision = c.getInt(12);
        r.pts = ptsFromJson(c.getString(13));
        return r;
    }

    private String ptsToJson(List<Route.Point> pts) {
        JSONArray arr = new JSONArray();
        for (Route.Point p : pts) {
            try {
                JSONArray a = new JSONArray();
                a.put(Math.round(p.x * 10) / 10.0);
                a.put(Math.round(p.a * 10) / 10.0);
                a.put(Math.round(p.sp * 10) / 10.0);
                a.put(Math.round(p.lat * 1000000) / 1000000.0);
                a.put(Math.round(p.lon * 1000000) / 1000000.0);
                arr.put(a);
            } catch (Exception ignored) {}
        }
        return arr.toString();
    }

    private List<Route.Point> ptsFromJson(String json) {
        List<Route.Point> pts = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONArray a = arr.getJSONArray(i);
                float x = (float) a.getDouble(0);
                float alt = (float) a.getDouble(1);
                float sp = (float) a.getDouble(2);
                float lat = a.length() > 3 ? (float) a.getDouble(3) : 0;
                float lon = a.length() > 4 ? (float) a.getDouble(4) : 0;
                pts.add(new Route.Point(x, alt, sp, lat, lon));
            }
        } catch (Exception ignored) {}
        return pts;
    }
}
