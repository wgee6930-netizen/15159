package com.traj.app;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;

public class SensorFusionManager implements SensorEventListener {
    public interface FusionCallback {
        void onOrientationUpdate(float heading, float pitch, float roll);
        void onStepUpdate(int steps, float distance, float stepLength);
        void onGravityUpdate(float gx, float gy, float gz);
        void onAccuracyChanged(int accuracy);
    }

    private final SensorManager sm;
    private Sensor gameRV, accel, gyro, mag, stepDetector;
    private FusionCallback callback;

    // Game rotation vector (preferred - smooth, no magnetic interference)
    private boolean useGameRV = false;
    private float[] rvMatrix = new float[9];
    private float[] rvOrient = new float[3];

    // Fallback: complementary filter
    private float[] gravity = new float[3];
    private float[] geomag = new float[3];
    private float[] gyroAngle = {0, 0, 0};
    private long lastGyroTime = 0;
    private boolean gyroInitialized = false;
    private boolean hasMag = false;

    // Smoothed heading - aggressive smoothing for fluid compass
    private float smoothHeading = 0;
    private float smoothPitch = 0;
    private float smoothRoll = 0;
    private boolean orientationInit = false;

    // For compass: use exponential smoothing with adaptive alpha
    // Fast movement → higher alpha (more responsive)
    // Slow movement → lower alpha (more stable)
    private static final float BASE_ALPHA = 0.2f;
    private static final float ADAPTIVE_FACTOR = 0.5f;
    private float lastHeadingDelta = 0;

    // Step counter
    private int totalSteps = 0;
    private float totalDistance = 0;
    private float lastStepLength = 0.72f;
    private long lastStepTime = 0;
    private int initialSteps = -1;
    private boolean useStepDetector = false;

    // Step length estimation
    private float peakAccel = 0, valleyAccel = 100;
    private static final float GRAVITY = 9.80665f;

    // Raw accelerometer values (m/s²)
    private float rawAccelX, rawAccelY, rawAccelZ;

    // Gravity for bubble level
    private float gravX, gravY, gravZ;

    // Heading interpolation for ultra-smooth display
    private float displayHeading = 0;
    private float targetHeading = 0;
    private long lastUpdateTime = 0;
    private static final float INTERP_SPEED = 12f; // radians/sec

    public SensorFusionManager(Context ctx) {
        sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);

        // Always initialize accelerometer — needed for bubble level, raw data, and step detection
        accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        // Try game rotation vector first (smooth, no magnetometer needed)
        gameRV = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);

        if (gameRV == null) {
            // Fallback to gyro + magnetometer for orientation
            gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        }

        // Gravity sensor (some devices have dedicated gravity sensor, more stable than accel filter)
        Sensor gravitySensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if (gravitySensor != null) {
            // Use dedicated gravity sensor if available
            sm.registerListener(this, gravitySensor, SensorManager.SENSOR_DELAY_GAME);
        }

        stepDetector = sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        if (stepDetector != null) useStepDetector = true;

        // Also try step counter (cumulative steps, more reliable on some devices)
        Sensor stepCounter = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (stepCounter != null && stepDetector == null) {
            // Use step counter as fallback if step detector not available
            sm.registerListener(this, stepCounter, SensorManager.SENSOR_DELAY_FASTEST);
        }
    }

    public void start(FusionCallback cb) {
        this.callback = cb;

        if (gameRV != null) {
            useGameRV = true;
            sm.registerListener(this, gameRV, SensorManager.SENSOR_DELAY_GAME);
        } else {
            if (gyro != null) sm.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
            if (mag != null) sm.registerListener(this, mag, SensorManager.SENSOR_DELAY_UI);
        }

        // Always register accelerometer for bubble level gravity vector
        if (accel != null) sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME);

        if (stepDetector != null) sm.registerListener(this, stepDetector, SensorManager.SENSOR_DELAY_FASTEST);

        lastUpdateTime = SystemClock.elapsedRealtime();
    }

    public void stop() {
        sm.unregisterListener(this);
    }

    public void reset() {
        totalSteps = 0;
        totalDistance = 0;
        initialSteps = -1;
        lastStepTime = 0;
        gyroInitialized = false;
        gyroAngle = new float[]{0, 0, 0};
        orientationInit = false;
        peakAccel = 0;
        valleyAccel = 100;
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        switch (e.sensor.getType()) {
            case Sensor.TYPE_GAME_ROTATION_VECTOR:
                handleGameRV(e);
                break;
            case Sensor.TYPE_ACCELEROMETER:
                handleAccel(e);
                break;
            case Sensor.TYPE_GYROSCOPE:
                handleGyro(e);
                break;
            case Sensor.TYPE_MAGNETIC_FIELD:
                handleMag(e);
                break;
            case Sensor.TYPE_STEP_DETECTOR:
                handleStepDetector(e);
                break;
            case Sensor.TYPE_GRAVITY:
                handleGravitySensor(e);
                break;
            case Sensor.TYPE_STEP_COUNTER:
                handleStepCounter(e);
                break;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor s, int a) {
        if (callback != null) callback.onAccuracyChanged(a);
    }

    // === Game Rotation Vector (primary, smooth) ===

    private void handleGameRV(SensorEvent e) {
        SensorManager.getRotationMatrixFromVector(rvMatrix, e.values);
        SensorManager.getOrientation(rvMatrix, rvOrient);

        float newHeading = rvOrient[0]; // azimuth
        float newPitch = rvOrient[1];   // pitch
        float newRoll = rvOrient[2];    // roll

        // Gravity vector comes from accelerometer (handleAccel), not from rotation matrix
        // This ensures correct physical direction for bubble level

        smoothOrientation(newHeading, newPitch, newRoll);
    }

    // === Fallback: Accel + Gyro + Mag ===

    private void handleAccel(SensorEvent e) {
        // Store raw accelerometer values
        rawAccelX = e.values[0];
        rawAccelY = e.values[1];
        rawAccelZ = e.values[2];

        float alpha = 0.8f;
        gravity[0] = alpha * gravity[0] + (1 - alpha) * e.values[0];
        gravity[1] = alpha * gravity[1] + (1 - alpha) * e.values[1];
        gravity[2] = alpha * gravity[2] + (1 - alpha) * e.values[2];

        gravX = gravity[0] / GRAVITY;
        gravY = gravity[1] / GRAVITY;
        gravZ = gravity[2] / GRAVITY;

        float mag = (float) Math.sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]);
        if (mag > peakAccel) peakAccel = mag;
        if (mag < valleyAccel) valleyAccel = mag;

        if (!useGameRV) updateOrientationFallback();

        if (callback != null) callback.onGravityUpdate(gravX, gravY, gravZ);
    }

    private void handleGyro(SensorEvent e) {
        if (useGameRV) return;
        if (!gyroInitialized) { gyroInitialized = true; lastGyroTime = e.timestamp; return; }
        float dt = (e.timestamp - lastGyroTime) / 1e9f;
        lastGyroTime = e.timestamp;
        if (dt <= 0 || dt > 0.5f) return;

        gyroAngle[0] += e.values[0] * dt;
        gyroAngle[1] += e.values[1] * dt;
        gyroAngle[2] += e.values[2] * dt;

        updateOrientationFallback();
    }

    private void handleMag(SensorEvent e) {
        if (useGameRV) return;
        geomag[0] = e.values[0]; geomag[1] = e.values[1]; geomag[2] = e.values[2];
        hasMag = true;
        updateOrientationFallback();
    }

    private void updateOrientationFallback() {
        float newHeading;
        if (hasMag && accel != null) {
            float[] R = new float[9], I = new float[9];
            if (SensorManager.getRotationMatrix(R, I, gravity, geomag)) {
                float[] o = new float[3];
                SensorManager.getOrientation(R, o);
                newHeading = o[0];
            } else {
                newHeading = gyroAngle[2];
            }
        } else {
            newHeading = gyroAngle[2];
        }

        float newPitch = (float) Math.atan2(gravity[2], Math.sqrt(gravity[0] * gravity[0] + gravity[1] * gravity[1]));
        float newRoll = (float) Math.atan2(-gravity[0], gravity[2]);

        smoothOrientation(newHeading, newPitch, newRoll);
    }

    // === Common smoothing (Xiaomi-style) ===

    private void smoothOrientation(float newHeading, float newPitch, float newRoll) {
        if (!orientationInit) {
            smoothHeading = newHeading;
            smoothPitch = newPitch;
            smoothRoll = newRoll;
            targetHeading = newHeading;
            displayHeading = newHeading;
            orientationInit = true;
        } else {
            // Adaptive alpha: larger heading changes → more responsive
            float headingDiff = newHeading - smoothHeading;
            while (headingDiff > Math.PI) headingDiff -= 2 * Math.PI;
            while (headingDiff < -Math.PI) headingDiff += 2 * Math.PI;

            float absDiff = Math.abs(headingDiff);
            float alpha = BASE_ALPHA + ADAPTIVE_FACTOR * Math.min(absDiff / (float) Math.PI, 1.0f);
            alpha = Math.min(alpha, 0.8f);

            smoothHeading += alpha * headingDiff;
            while (smoothHeading > Math.PI) smoothHeading -= 2 * Math.PI;
            while (smoothHeading < -Math.PI) smoothHeading += 2 * Math.PI;

            smoothPitch = 0.3f * smoothPitch + 0.7f * newPitch;
            smoothRoll = 0.3f * smoothRoll + 0.7f * newRoll;
        }

        // Interpolate display heading for ultra-smooth rendering
        targetHeading = smoothHeading;
        long now = SystemClock.elapsedRealtime();
        float dt = (now - lastUpdateTime) / 1000f;
        lastUpdateTime = now;

        if (dt > 0 && dt < 0.2f) {
            float diff = targetHeading - displayHeading;
            while (diff > Math.PI) diff -= 2 * Math.PI;
            while (diff < -Math.PI) diff += 2 * Math.PI;

            float maxStep = INTERP_SPEED * dt;
            if (Math.abs(diff) < maxStep) {
                displayHeading = targetHeading;
            } else {
                displayHeading += Math.signum(diff) * maxStep;
            }
            while (displayHeading > Math.PI) displayHeading -= 2 * Math.PI;
            while (displayHeading < -Math.PI) displayHeading += 2 * Math.PI;
        }

        if (callback != null) callback.onOrientationUpdate(displayHeading, smoothPitch, smoothRoll);
    }

    // === Step detection ===

    private void handleStepDetector(SensorEvent e) {
        totalSteps++;
        long now = System.currentTimeMillis();

        if (lastStepTime > 0) {
            float dt = (now - lastStepTime) / 1000f;
            if (dt > 0.2f && dt < 3f) {
                float freq = 1f / dt;
                float amplitude = (peakAccel - valleyAccel) / GRAVITY;
                lastStepLength = 0.4f + 0.35f * amplitude + 0.05f * (freq - 1.8f);
                lastStepLength = Math.max(0.35f, Math.min(1.3f, lastStepLength));
                peakAccel = 0;
                valleyAccel = 100;
            }
        }
        lastStepTime = now;
        totalDistance = totalSteps * lastStepLength;

        if (callback != null) callback.onStepUpdate(totalSteps, totalDistance, lastStepLength);
    }

    // === Dedicated gravity sensor (more stable than accel low-pass filter) ===

    private void handleGravitySensor(SensorEvent e) {
        // Use dedicated gravity sensor - more stable than accelerometer low-pass filter
        gravity[0] = e.values[0];
        gravity[1] = e.values[1];
        gravity[2] = e.values[2];

        gravX = e.values[0] / GRAVITY;
        gravY = e.values[1] / GRAVITY;
        gravZ = e.values[2] / GRAVITY;

        if (callback != null) callback.onGravityUpdate(gravX, gravY, gravZ);
    }

    // === Step counter (cumulative, fallback for step detector) ===

    private float stepCounterBase = -1;

    private void handleStepCounter(SensorEvent e) {
        if (stepCounterBase < 0) {
            stepCounterBase = e.values[0];
            return;
        }
        int newSteps = (int)(e.values[0] - stepCounterBase);
        if (newSteps > totalSteps) {
            totalSteps = newSteps;
            long now = System.currentTimeMillis();
            if (lastStepTime > 0) {
                float dt = (now - lastStepTime) / 1000f;
                if (dt > 0.2f && dt < 3f) {
                    float freq = 1f / dt;
                    float amplitude = (peakAccel - valleyAccel) / GRAVITY;
                    lastStepLength = 0.4f + 0.35f * amplitude + 0.05f * (freq - 1.8f);
                    lastStepLength = Math.max(0.35f, Math.min(1.3f, lastStepLength));
                    peakAccel = 0;
                    valleyAccel = 100;
                }
            }
            lastStepTime = now;
            totalDistance = totalSteps * lastStepLength;
            if (callback != null) callback.onStepUpdate(totalSteps, totalDistance, lastStepLength);
        }
    }

    // === Getters ===

    public boolean isGameRVAvailable() { return gameRV != null; }
    public boolean isGyroAvailable() { return gyro != null; }
    public boolean isMagAvailable() { return mag != null; }
    public boolean isStepDetectorAvailable() { return stepDetector != null; }
    public int getTotalSteps() { return totalSteps; }
    public float getTotalDistance() { return totalDistance; }
    public float getStepFrequency() {
        long now = System.currentTimeMillis();
        if (lastStepTime <= 0) return 0;
        float dt = (now - lastStepTime) / 1000f;
        return dt > 0 && dt < 3 ? 1f / dt : 0;
    }
    public float getGravX() { return gravX; }
    public float getGravY() { return gravY; }
    public float getGravZ() { return gravZ; }
    public float getRawAccelX() { return rawAccelX; }
    public float getRawAccelY() { return rawAccelY; }
    public float getRawAccelZ() { return rawAccelZ; }
}
