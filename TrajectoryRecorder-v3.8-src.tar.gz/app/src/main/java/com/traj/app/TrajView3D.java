package com.traj.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import java.util.List;

public class TrajView3D extends View {
    private final Paint pGrid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);

    private Route route;
    private float rx = -0.55f, ry = 0.35f; // rotation
    private float zoom = 1;
    private float curDist = -1;
    private float maxSp = 1;
    private boolean fitted = false;

    private float lastX, lastY;

    public TrajView3D(Context c) { this(c, null); }
    public TrajView3D(Context c, AttributeSet a) { this(c, a, 0); }
    public TrajView3D(Context c, AttributeSet a, int d) {
        super(c, a, d);
        pGrid.setColor(Color.argb(30, 48, 54, 61));
        pGrid.setStrokeWidth(1);
        pGrid.setStyle(Paint.Style.STROKE);
        pLine.setStrokeWidth(5);
        pLine.setStrokeCap(Paint.Cap.ROUND);
        pLine.setStrokeJoin(Paint.Join.ROUND);
        pLine.setStyle(Paint.Style.STROKE);
        pDot.setStyle(Paint.Style.FILL);
        pText.setColor(Color.parseColor("#8B949E"));
        pText.setTextSize(22);
    }

    public void setRoute(Route r) {
        this.route = r;
        fitted = false;
        maxSp = 1;
        if (r != null) {
            for (Route.Point p : r.pts) if (p.sp > maxSp) maxSp = p.sp;
        }
        fitCamera();
        invalidate();
    }

    public void setCurrentDist(float d) {
        this.curDist = d;
        invalidate();
    }

    private void fitCamera() {
        if (route == null || route.pts.isEmpty()) return;
        fitted = true;
        float dMax = route.pts.get(route.pts.size() - 1).x;
        float sc = 100f / Math.max(dMax, 100);
        float am = avgAlt();

        float sx0 = Float.MAX_VALUE, sx1 = -Float.MAX_VALUE;
        float sy0 = Float.MAX_VALUE, sy1 = -Float.MAX_VALUE;
        float cx = getWidth() / 2f, cy = getHeight() / 2f;

        for (int i = 0; i < route.pts.size(); i += Math.max(1, route.pts.size() / 100)) {
            Route.Point pt = route.pts.get(i);
            float[] p = project(pt.x * sc, (pt.a + route.altOff - am) * sc, 0, cx, cy);
            if (p[0] < sx0) sx0 = p[0]; if (p[0] > sx1) sx1 = p[0];
            if (p[1] < sy0) sy0 = p[1]; if (p[1] > sy1) sy1 = p[1];
        }
        float bw = sx1 - sx0, bh = sy1 - sy0;
        if (bw > 1 && bh > 1) {
            zoom = Math.min(getWidth() * 0.85f / bw, getHeight() * 0.85f / bh);
        } else zoom = 1;
        zoom = Math.max(zoom, 0.01f);
    }

    private float avgAlt() {
        if (route == null || route.pts.isEmpty()) return 0;
        float sum = 0;
        for (Route.Point p : route.pts) sum += p.a + route.altOff;
        return sum / route.pts.size();
    }

    private float[] project(float x, float y, float z, float cx, float cy) {
        float cosR = (float) Math.cos(ry), sinR = (float) Math.sin(ry);
        float cosP = (float) Math.cos(rx), sinP = (float) Math.sin(rx);
        float x1 = x * cosR - z * sinR;
        float z1 = x * sinR + z * cosR;
        float y1 = y * cosP - z1 * sinP;
        float z2 = y * sinP + z1 * cosP;
        float scale = zoom * 180 / Math.max(z2 + 500, 1);
        return new float[]{cx + x1 * scale, cy - y1 * scale};
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        c.drawColor(Color.parseColor("#0d0d12"));

        if (route == null || route.pts.isEmpty()) return;
        List<Route.Point> pts = route.pts;
        float dMax = pts.get(pts.size() - 1).x;
        float sc = 100f / Math.max(dMax, 100);
        float am = avgAlt();
        float cx = w / 2, cy = h / 2;

        // 网格
        for (int gx = -100; gx <= 100; gx += 20) {
            float[] g1 = project(gx, 0, -100, cx, cy);
            float[] g2 = project(gx, 0, 100, cx, cy);
            c.drawLine(g1[0], g1[1], g2[0], g2[1], pGrid);
        }
        for (int gz = -100; gz <= 100; gz += 20) {
            float[] g1 = project(-100, 0, gz, cx, cy);
            float[] g2 = project(100, 0, gz, cx, cy);
            c.drawLine(g1[0], g1[1], g2[0], g2[1], pGrid);
        }

        // 轨迹线
        for (int i = 1; i < pts.size(); i++) {
            float[] p1 = project(pts.get(i - 1).x * sc, (pts.get(i - 1).a + route.altOff - am) * sc, 0, cx, cy);
            float[] p2 = project(pts.get(i).x * sc, (pts.get(i).a + route.altOff - am) * sc, 0, cx, cy);
            pLine.setColor(spdColor(pts.get(i).sp, maxSp));
            c.drawLine(p1[0], p1[1], p2[0], p2[1], pLine);
        }

        // 起点/终点
        float[] sp = project(pts.get(0).x * sc, (pts.get(0).a + route.altOff - am) * sc, 0, cx, cy);
        pDot.setColor(Color.parseColor("#00FF88"));
        c.drawCircle(sp[0], sp[1], 8, pDot);
        float[] ep = project(pts.get(pts.size() - 1).x * sc, (pts.get(pts.size() - 1).a + route.altOff - am) * sc, 0, cx, cy);
        pDot.setColor(Color.parseColor("#FF3344"));
        c.drawCircle(ep[0], ep[1], 8, pDot);

        // 当前位置
        if (curDist >= 0 && curDist <= dMax) {
            int idx = findClosest(curDist);
            float[] lp = project(pts.get(idx).x * sc, (pts.get(idx).a + route.altOff - am) * sc, 0, cx, cy);
            pDot.setColor(Color.parseColor("#00D4FF"));
            c.drawCircle(lp[0], lp[1], 10, pDot);
        }
    }

    private int findClosest(float d) {
        if (route == null) return 0;
        int best = 0; float bd = Float.MAX_VALUE;
        for (int i = 0; i < route.pts.size(); i++) {
            float dd = Math.abs(route.pts.get(i).x - d);
            if (dd < bd) { bd = dd; best = i; }
        }
        return best;
    }

    private int spdColor(float sp, float maxSp) {
        if (maxSp <= 0) return Color.parseColor("#00FF88");
        float t = Math.min(sp / maxSp, 1);
        int r = t < 0.5f ? (int) (t * 2 * 255) : 255;
        int g = t < 0.5f ? 255 : (int) (255 - (t - 0.5f) * 2 * 255);
        return Color.rgb(r, g, 0);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                lastX = e.getX(); lastY = e.getY();
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx = e.getX() - lastX, dy = e.getY() - lastY;
                ry += dx * 0.005f;
                rx += dy * 0.005f;
                rx = Math.max(-1.5f, Math.min(1.5f, rx));
                lastX = e.getX(); lastY = e.getY();
                invalidate();
                return true;
        }
        return super.onTouchEvent(e);
    }
}
