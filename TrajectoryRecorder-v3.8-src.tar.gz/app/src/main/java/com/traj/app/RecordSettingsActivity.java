package com.traj.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Locale;

public class RecordSettingsActivity extends Activity {
    private SharedPreferences prefs;
    private RadioGroup rgPrecision;
    private RadioButton rb01, rb05, rb1;
    private Switch swGps;
    private EditText etBaseAlt;

    /** Lock font scale to 1.0 — prevents text size drift on language switch */
    @Override
    public Resources getResources() {
        Resources res = super.getResources();
        if (res.getConfiguration().fontScale != 1.0f) {
            Configuration cfg = new Configuration(res.getConfiguration());
            cfg.fontScale = 1.0f;
            res.updateConfiguration(cfg, res.getDisplayMetrics());
        }
        return res;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyLocale();
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#0d1117"));
            getWindow().setStatusBarColor(Color.parseColor("#0d1117"));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().getInsetsController().hide(
                android.view.WindowInsets.Type.statusBars() | android.view.WindowInsets.Type.navigationBars());
            getWindow().getInsetsController().setSystemBarsBehavior(
                android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
        setContentView(R.layout.activity_record_settings);

        prefs = getSharedPreferences("traj", MODE_PRIVATE);

        rgPrecision = findViewById(R.id.rgPrecision);
        rb01 = findViewById(R.id.rbPrec01);
        rb05 = findViewById(R.id.rbPrec05);
        rb1 = findViewById(R.id.rbPrec1);
        swGps = findViewById(R.id.swGps);
        etBaseAlt = findViewById(R.id.etBaseAlt);

        // Load saved settings
        int prec = prefs.getInt("precision", 0);
        switch (prec) {
            case 0: rb01.setChecked(true); break;
            case 1: rb05.setChecked(true); break;
            case 2: rb1.setChecked(true); break;
        }
        swGps.setChecked(prefs.getBoolean("gps", false));
        float baseAlt = prefs.getFloat("baseAlt", 0);
        if (baseAlt != 0) etBaseAlt.setText(String.valueOf(baseAlt));

        // Back button
        findViewById(R.id.btnBack).setOnClickListener(v -> saveAndFinish());
    }

    /** Apply saved locale (font scale locked by getResources() override) */
    private void applyLocale() {
        String lang = getSharedPreferences("traj", MODE_PRIVATE).getString("lang", "");
        if (lang.isEmpty()) return;
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Resources res = getResources();
        Configuration cfg = res.getConfiguration();
        cfg.setLocale(locale);
        res.updateConfiguration(cfg, res.getDisplayMetrics());
    }

    private void saveAndFinish() {
        SharedPreferences.Editor ed = prefs.edit();

        // Precision
        int prec = 0;
        if (rb05.isChecked()) prec = 1;
        else if (rb1.isChecked()) prec = 2;
        ed.putInt("precision", prec);

        // GPS
        ed.putBoolean("gps", swGps.isChecked());

        // Base altitude
        try {
            float alt = Float.parseFloat(etBaseAlt.getText().toString());
            ed.putFloat("baseAlt", alt);
        } catch (NumberFormatException e) {
            ed.putFloat("baseAlt", 0);
        }

        ed.apply();
        finish();
    }

    @Override
    public void onBackPressed() {
        saveAndFinish();
    }
}
