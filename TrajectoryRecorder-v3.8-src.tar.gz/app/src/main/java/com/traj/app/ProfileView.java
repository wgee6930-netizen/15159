package com.traj.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import java.util.List;

public class ProfileView extends View {
    private final Paint pBg = new Paint();
    private final Paint pLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pGrid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pCur = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path linePath = new Path();
    private final Path fillPath = new Path();

    private Route route;
    private float curDist = -1; // current position distance
    private float maxSp = 1;

    public ProfileView(Context c) { this(c, null); }
    public ProfileView(Context c, AttributeSet a) { this(c, a, 0); }
    public ProfileView(Context c, AttributeSet a, int d) {
        super(c, a, d);
        pBg.setColor(Color.parseColor("#0d1117"));
        pLine.setColor(Color.parseColor("#00D4FF"));
        pLine.setStrokeWidth(4);
        pLine.setStyle(Paint.Style.STROKE);
        pGrid.setColor(Color.argb(40, 48, 54, 61));
        pGrid.setStrokeWidth(1);
        pText.setColor(Color.parseColor("#8B949E"));
        pText.setTextSize(24);
        pText.setTextAlign(Paint.Align.RIGHT);
        pDot.setColor(Color.parseColor("#00FF88"));
        pCur.setColor(Color.parseColor("#00D4FF"));
        pCur.setStyle(Paint.Style.STROKE);
        pCur.setStrokeWidth(2);
    }

    public void setRoute(Route r) {
        this.route = r;
        maxSp = 1;
        if (r != null) {
            for (Route.Point p : r.pts) if (p.sp > maxSp) maxSp = p.sp;
        }
        invalidate();
    }

    public void setCurrentDist(float d) {
        this.curDist = d;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float L = 60, R = 16, T = 16, B = 32;
        float pw = w - L - R, ph = h - T - B;

        c.drawColor(Color.parseColor("#0d1117"));

        if (route == null || route.pts.isEmpty()) return;
        List<Route.Point> pts = route.pts;
        float dMax = pts.get(pts.size() - 1).x;
        if (dMax <= 0) return;

        // 计算Y范围
        float aMin = Float.MAX_VALUE, aMax = -Float.MAX_VALUE;
        for (Route.Point p : pts) {
            float a = p.a + route.altOff;
            if (a < aMin) aMin = a;
            if (a > aMax) aMax = a;
        }
        float margin = (aMax - aMin) * 0.15f;
        aMin -= margin; aMax += margin;
        if (aMax <= aMin) aMax = aMin + 1;

        // 网格线
        float yStep = niceStep(aMax - aMin, ph);
        for (float ya = (float) Math.ceil(aMin / yStep) * yStep; ya <= aMax; ya += yStep) {
            float py = T + ph - (ya - aMin) / (aMax - aMin) * ph;
            if (py > T + 10 && py < T + ph - 10) {
                c.drawLine(L, py, w - R, py, pGrid);
                pText.setTextAlign(Paint.Align.RIGHT);
                c.drawText(String.format("%.0fm", ya), L - 8, py + 8, pText);
            }
        }

        // X网格
        float xStep = niceStep(dMax, pw);
        for (float xd = 0; xd <= dMax; xd += xStep) {
            float px = L + xd / dMax * pw;
            if (px > L + 20 && px < w - R - 20) {
                c.drawLine(px, T, px, T + ph, pGrid);
                pText.setTextAlign(Paint.Align.CENTER);
                c.drawText(xd >= 1000 ? String.format("%.1fkm", xd / 1000) : String.format("%.0fm", xd),
                    px, T + ph + 24, pText);
            }
        }

        // 轴线
        pGrid.setColor(Color.argb(200, 48, 54, 61));
        c.drawLine(L, T, L, T + ph, pGrid);
        c.drawLine(L, T + ph, w - R, T + ph, pGrid);

        // 填充渐变
        linePath.reset();
        fillPath.reset();
        boolean started = false;
        for (int i = 0; i < pts.size(); i++) {
            float px = L + pts.get(i).x / dMax * pw;
            float py = T + ph - (pts.get(i).a + route.altOff - aMin) / (aMax - aMin) * ph;
            if (!started) { linePath.moveTo(px, py); fillPath.moveTo(px, T + ph); fillPath.lineTo(px, py); started = true; }
            else { linePath.lineTo(px, py); fillPath.lineTo(px, py); }
        }
        fillPath.lineTo(L + pts.get(pts.size() - 1).x / dMax * pw, T + ph);
        fillPath.close();

        pFill.setShader(new LinearGradient(0, T, 0, T + ph,
            Color.argb(50, 0, 212, 255), Color.argb(2, 0, 212, 255), Shader.TileMode.CLAMP));
        c.drawPath(fillPath, pFill);
        c.drawPath(linePath, pLine);

        // 起点/终点
        float sx = L + pts.get(0).x / dMax * pw;
        float sy = T + ph - (pts.get(0).a + route.altOff - aMin) / (aMax - aMin) * ph;
        pDot.setColor(Color.parseColor("#00FF88"));
        c.drawCircle(sx, sy, 6, pDot);
        float ex = L + pts.get(pts.size() - 1).x / dMax * pw;
        float ey = T + ph - (pts.get(pts.size() - 1).a + route.altOff - aMin) / (aMax - aMin) * ph;
        pDot.setColor(Color.parseColor("#FF3344"));
        c.drawCircle(ex, ey, 6, pDot);

        // 当前位置
        if (curDist >= 0 && curDist <= dMax) {
            float cx2 = L + curDist / dMax * pw;
            c.drawLine(cx2, T, cx2, T + ph, pCur);
            pCur.setStyle(Paint.Style.FILL);
            c.drawCircle(cx2, T + ph, 5, pCur);
            pCur.setStyle(Paint.Style.STROKE);
        }
    }

    private float niceStep(float range, float px) {
        if (range <= 0 || px <= 0) return 1;
        float raw = range / Math.max(px / 60, 1);
        float mag = (float) Math.pow(10, Math.floor(Math.log10(raw)));
        float norm = raw / mag;
        if (norm < 1.5f) return mag;
        if (norm < 3.5f) return 2 * mag;
        if (norm < 7.5f) return 5 * mag;
        return 10 * mag;
    }
}
