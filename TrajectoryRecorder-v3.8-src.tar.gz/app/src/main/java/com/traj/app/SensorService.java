package com.traj.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

public class SensorService extends Service {
    public static final String ACTION_DATA = "com.traj.app.SENSOR_DATA";
    public static final String CHANNEL_ID = "traj_rec";

    private PowerManager.WakeLock wakeLock;
    private SensorFusionManager sensorFusion;
    private boolean recording = false;
    private boolean foregroundStarted = false;
    private long startTime = 0;

    private boolean gpsEnabled = false;
    private float baseAltitude = 0;
    private float recordPrecisionM = 0.1f;

    private float totalDist = 0, totalAsc = 0;
    private float lastRecordedDist = -1;

    private float heading, pitch, roll;
    private int steps;
    private float sensorDist;

    private LocationManager locationManager;
    private Location startLocation;
    private float currentLat, currentLon;
    private boolean gpsFixed = false;
    private static final float GPS_ACCURACY = 3.0f;

    private final Handler handler = new Handler(Looper.getMainLooper());

    // Broadcast sensor data every 100ms for smooth compass
    private final Runnable sensorTicker = new Runnable() {
        @Override public void run() {
            broadcastSensorData();
            handler.postDelayed(this, 100);
        }
    };

    // Recording tick (distance/altitude tracking)
    private final Runnable recordTicker = new Runnable() {
        @Override public void run() {
            if (!recording) return;
            trackRecording();
            handler.postDelayed(this, 500);
        }
    };

    private final IBinder binder = new LocalBinder();
    public class LocalBinder extends Binder {
        public SensorService getService() { return SensorService.this; }
    }

    @Override
    public IBinder onBind(Intent i) { return binder; }

    @Override
    public void onCreate() {
        super.onCreate();

        // Create notification channel early (required before startForeground on Android 8+)
        createChannel();

        sensorFusion = new SensorFusionManager(this);
        sensorFusion.start(new SensorFusionManager.FusionCallback() {
            @Override public void onOrientationUpdate(float h, float p, float r) {
                heading = h; pitch = p; roll = r;
            }
            @Override public void onStepUpdate(int s, float d, float l) {
                steps = s; sensorDist = d;
            }
            @Override public void onGravityUpdate(float gx, float gy, float gz) {}
            @Override public void onAccuracyChanged(int a) {}
        });

        // Start continuous sensor broadcast (for compass + calibration)
        handler.post(sensorTicker);
    }

    /** Broadcast current sensor data to activity (always, not just when recording) */
    private void broadcastSensorData() {
        Intent i = new Intent(ACTION_DATA);
        i.putExtra("dist", recording ? totalDist : 0f);
        i.putExtra("asc", recording ? totalAsc : 0f);
        i.putExtra("steps", steps);
        i.putExtra("heading", heading);
        i.putExtra("pitch", pitch);
        i.putExtra("roll", roll);
        i.putExtra("altitude", recording ? baseAltitude + totalAsc : baseAltitude);
        i.putExtra("speed", recording && sensorFusion != null ? sensorFusion.getStepFrequency() * 0.72f : 0f);
        i.putExtra("elapsed", recording ? System.currentTimeMillis() - startTime : 0L);
        i.putExtra("lat", 0f);
        i.putExtra("lon", 0f);
        i.putExtra("gravX", sensorFusion != null ? sensorFusion.getGravX() : 0);
        i.putExtra("gravY", sensorFusion != null ? sensorFusion.getGravY() : 0);
        i.putExtra("gravZ", sensorFusion != null ? sensorFusion.getGravZ() : 1);
        // Raw accelerometer (m/s²)
        i.putExtra("accelX", sensorFusion != null ? sensorFusion.getRawAccelX() : 0);
        i.putExtra("accelY", sensorFusion != null ? sensorFusion.getRawAccelY() : 0);
        i.putExtra("accelZ", sensorFusion != null ? sensorFusion.getRawAccelZ() : 0);
        i.putExtra("recording", recording);
        sendBroadcast(i);
    }

    /** Track distance/altitude while recording */
    private void trackRecording() {
        totalDist = sensorDist;
        float da = (float) Math.sin(pitch) * (sensorDist - (lastRecordedDist >= 0 ? lastRecordedDist : 0));
        if (Math.abs(da) < 5 && Math.abs(da) > 0.05f) totalAsc += da;
        lastRecordedDist = sensorDist;

        // GPS coordinates
        float latVal = 0, lonVal = 0;
        if (gpsEnabled && gpsFixed && startLocation != null) {
            float[] r = new float[1];
            Location.distanceBetween(startLocation.getLatitude(), startLocation.getLongitude(),
                currentLat, currentLon, r);
            latVal = r[0];
        } else {
            latVal = (float) (totalDist * Math.cos(heading));
            lonVal = (float) (totalDist * Math.sin(heading));
        }

        // Extra data for recording broadcast
        Intent i = new Intent(ACTION_DATA);
        i.putExtra("dist", totalDist);
        i.putExtra("asc", totalAsc);
        i.putExtra("steps", steps);
        i.putExtra("heading", heading);
        i.putExtra("pitch", pitch);
        i.putExtra("roll", roll);
        i.putExtra("altitude", baseAltitude + totalAsc);
        i.putExtra("speed", sensorFusion != null ? sensorFusion.getStepFrequency() * 0.72f : 0f);
        i.putExtra("elapsed", System.currentTimeMillis() - startTime);
        i.putExtra("lat", latVal);
        i.putExtra("lon", lonVal);
        i.putExtra("gravX", sensorFusion != null ? sensorFusion.getGravX() : 0);
        i.putExtra("gravY", sensorFusion != null ? sensorFusion.getGravY() : 0);
        i.putExtra("gravZ", sensorFusion != null ? sensorFusion.getGravZ() : 1);
        // Raw accelerometer (m/s²)
        i.putExtra("accelX", sensorFusion != null ? sensorFusion.getRawAccelX() : 0);
        i.putExtra("accelY", sensorFusion != null ? sensorFusion.getRawAccelY() : 0);
        i.putExtra("accelZ", sensorFusion != null ? sensorFusion.getRawAccelZ() : 0);
        i.putExtra("recording", true);
        sendBroadcast(i);
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        return START_STICKY;
    }

    public void applySettings(boolean gps, float baseAlt, int precisionIdx) {
        this.gpsEnabled = gps;
        this.baseAltitude = baseAlt;
        switch (precisionIdx) {
            case 0: recordPrecisionM = 0.1f; break;
            case 1: recordPrecisionM = 0.5f; break;
            case 2: recordPrecisionM = 1.0f; break;
        }
        if (gpsEnabled) startGps();
    }

    private void startGps() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                1000, 0, gpsListener, Looper.getMainLooper());
        } catch (SecurityException e) {
            gpsEnabled = false;
        }
    }

    private void stopGps() {
        if (locationManager != null) {
            try { locationManager.removeUpdates(gpsListener); } catch (Exception ignored) {}
        }
    }

    private final LocationListener gpsListener = new LocationListener() {
        @Override public void onLocationChanged(Location loc) {
            if (!gpsFixed && loc.getAccuracy() <= GPS_ACCURACY) {
                gpsFixed = true;
                startLocation = loc;
            }
            currentLat = (float) loc.getLatitude();
            currentLon = (float) loc.getLongitude();
        }
        @Override public void onStatusChanged(String s, int i, Bundle b) {}
        @Override public void onProviderEnabled(String s) {}
        @Override public void onProviderDisabled(String s) {}
    };

    public void startRecording() {
        if (recording) return;
        recording = true;
        startTime = System.currentTimeMillis();
        totalDist = 0; totalAsc = 0;
        lastRecordedDist = -1;
        sensorFusion.reset();

        if (!foregroundStarted) {
            createChannel();
            startForeground(1, buildNotif(getString(R.string.recording)));
            foregroundStarted = true;
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "traj:rec");
            wakeLock.acquire();
        }

        handler.post(recordTicker);
    }

    public void stopRecording() {
        recording = false;
        handler.removeCallbacks(recordTicker);
        stopGps();
    }

    public boolean isRecording() { return recording; }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(sensorTicker);
        handler.removeCallbacks(recordTicker);
        if (sensorFusion != null) sensorFusion.stop();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (foregroundStarted) stopForeground(true);
        super.onDestroy();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, getString(R.string.app_name),
                NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotif(String text) {
        Notification.Builder nb = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);
        return nb.setContentTitle(getString(R.string.app_name)).setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true).build();
    }
}
