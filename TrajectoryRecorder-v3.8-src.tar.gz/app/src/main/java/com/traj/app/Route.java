package com.traj.app;

import java.util.ArrayList;
import java.util.List;

public class Route {
    public long id;
    public String name;
    public long timestamp;
    public long duration;   // ms
    public float totalDist; // m
    public float totalAsc;  // m
    public float altOff;    // altitude calibration offset
    public float origAltOff;
    public float baseAlt;   // user-set base altitude (m)
    public boolean gpsEnabled;
    public float startLat;
    public float startLon;
    public int recordPrecision; // 0=0.1m, 1=0.5m, 2=1m
    public List<Point> pts = new ArrayList<>();

    public static class Point {
        public float x;   // cumulative distance (m)
        public float a;   // altitude (m)
        public float sp;  // speed (km/h)
        public float lat; // latitude (relative or GPS)
        public float lon; // longitude (relative or GPS)

        public Point(float x, float a, float sp) {
            this.x = x; this.a = a; this.sp = sp;
        }

        public Point(float x, float a, float sp, float lat, float lon) {
            this.x = x; this.a = a; this.sp = sp;
            this.lat = lat; this.lon = lon;
        }
    }
}
