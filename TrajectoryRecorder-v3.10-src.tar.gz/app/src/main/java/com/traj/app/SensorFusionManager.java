package com.traj.app;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;

public class SensorFusionManager implements SensorEventListener {
    public interface FusionCallback {
        void onOrientationUpdate(float heading, float pitch, float roll);
        void onStepUpdate(int steps, float distance, float stepLength);
        void onGravityUpdate(float gx, float gy, float gz);
        void onAccuracyChanged(int accuracy);
    }

    private final SensorManager sm;
    private Sensor gameRV, accel, gyro, mag;
    private FusionCallback callback;

    // Game rotation vector
    private boolean useGameRV = false;
    private float[] rvMatrix = new float[9];
    private float[] rvOrient = new float[3];

    // Fallback: complementary filter
    private float[] gravity = new float[3];
    private float[] geomag = new float[3];
    private float[] gyroAngle = {0, 0, 0};
    private long lastGyroTime = 0;
    private boolean gyroInitialized = false;
    private boolean hasMag = false;

    // Orientation smoothing
    private float smoothHeading = 0, smoothPitch = 0, smoothRoll = 0;
    private boolean orientationInit = false;
    private static final float BASE_ALPHA = 0.2f;
    private static final float ADAPTIVE_FACTOR = 0.5f;

    // Display heading interpolation
    private float displayHeading = 0, targetHeading = 0;
    private long lastUpdateTime = 0;
    private static final float INTERP_SPEED = 12f;

    // === Distance estimation (triple protection) ===

    // Layer 1: Step detection via accelerometer periodicity
    private int totalSteps = 0;
    private float totalDistance = 0;
    private float lastStepLength = 0.72f;
    private long lastStepTime = 0;
    private float peakAccel = 0, valleyAccel = 100;
    private static final float GRAVITY = 9.80665f;

    // Step detection via peak finding (works in pocket/bag)
    private float[] accelHistory = new float[64]; // circular buffer
    private int accelHistIdx = 0;
    private int accelHistCount = 0;
    private long lastPeakTime = 0;
    private boolean aboveMean = false;
    private float runningMean = GRAVITY;
    private static final float MEAN_ALPHA = 0.05f;
    private static final float PEAK_THRESHOLD = 0.4f; // m/s² above mean to count as step

    // Layer 2: Linear acceleration integration + ZUPT
    private float velocity = 0;
    private float integratedDist = 0;
    private long lastIntegrationTime = 0;
    private boolean integrationActive = false;

    // ZUPT (Zero-velocity Update)
    private float zuptAccelVariance = 0;
    private int zuptSampleCount = 0;
    private static final float ZUPT_VAR_THRESHOLD = 0.15f; // m/s² variance = stationary
    private static final int ZUPT_MIN_SAMPLES = 20; // ~0.5s at SENSOR_DELAY_GAME

    // Layer 3: Periodic ZUPT (every 5 minutes)
    private static final long PERIODIC_ZUPT_INTERVAL_MS = 5 * 60 * 1000; // 5 min
    private long lastPeriodicZuptTime = 0;
    private long totalIntegrationTimeMs = 0;

    // Time-based drift correction
    private static final float DRIFT_RATE = 0.03f; // m/s², sensor noise estimate

    // Gravity for bubble level
    private float gravX, gravY, gravZ;

    // Raw accelerometer values (m/s²)
    private float rawAccelX, rawAccelY, rawAccelZ;

    // Linear acceleration (accel - gravity)
    private float linearAccelX, linearAccelY, linearAccelZ;

    public SensorFusionManager(Context ctx) {
        sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gameRV = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);

        if (gameRV == null) {
            gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        }

        Sensor gravitySensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if (gravitySensor != null) {
            sm.registerListener(this, gravitySensor, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    public void start(FusionCallback cb) {
        this.callback = cb;

        if (gameRV != null) {
            useGameRV = true;
            sm.registerListener(this, gameRV, SensorManager.SENSOR_DELAY_GAME);
        } else {
            if (gyro != null) sm.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
            if (mag != null) sm.registerListener(this, mag, SensorManager.SENSOR_DELAY_UI);
        }

        if (accel != null) sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME);

        lastUpdateTime = SystemClock.elapsedRealtime();
    }

    public void stop() {
        sm.unregisterListener(this);
    }

    public void reset() {
        totalSteps = 0;
        totalDistance = 0;
        integratedDist = 0;
        velocity = 0;
        lastStepTime = 0;
        lastIntegrationTime = 0;
        lastPeriodicZuptTime = 0;
        totalIntegrationTimeMs = 0;
        integrationActive = false;
        gyroInitialized = false;
        gyroAngle = new float[]{0, 0, 0};
        orientationInit = false;
        peakAccel = 0;
        valleyAccel = 100;
        accelHistIdx = 0;
        accelHistCount = 0;
        lastPeakTime = 0;
        aboveMean = false;
        runningMean = GRAVITY;
        zuptSampleCount = 0;
        zuptAccelVariance = 0;
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        switch (e.sensor.getType()) {
            case Sensor.TYPE_GAME_ROTATION_VECTOR: handleGameRV(e); break;
            case Sensor.TYPE_ACCELEROMETER: handleAccel(e); break;
            case Sensor.TYPE_GYROSCOPE: handleGyro(e); break;
            case Sensor.TYPE_MAGNETIC_FIELD: handleMag(e); break;
            case Sensor.TYPE_GRAVITY: handleGravitySensor(e); break;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor s, int a) {
        if (callback != null) callback.onAccuracyChanged(a);
    }

    // === Game Rotation Vector ===

    private void handleGameRV(SensorEvent e) {
        SensorManager.getRotationMatrixFromVector(rvMatrix, e.values);
        SensorManager.getOrientation(rvMatrix, rvOrient);
        smoothOrientation(rvOrient[0], rvOrient[1], rvOrient[2]);
    }

    // === Accelerometer: gravity + step detection + integration ===

    private void handleAccel(SensorEvent e) {
        rawAccelX = e.values[0];
        rawAccelY = e.values[1];
        rawAccelZ = e.values[2];

        // Gravity (low-pass)
        float alpha = 0.8f;
        gravity[0] = alpha * gravity[0] + (1 - alpha) * e.values[0];
        gravity[1] = alpha * gravity[1] + (1 - alpha) * e.values[1];
        gravity[2] = alpha * gravity[2] + (1 - alpha) * e.values[2];

        gravX = gravity[0] / GRAVITY;
        gravY = gravity[1] / GRAVITY;
        gravZ = gravity[2] / GRAVITY;

        // Linear acceleration
        linearAccelX = e.values[0] - gravity[0];
        linearAccelY = e.values[1] - gravity[1];
        linearAccelZ = e.values[2] - gravity[2];

        float linearMag = (float) Math.sqrt(
            linearAccelX * linearAccelX + linearAccelY * linearAccelY + linearAccelZ * linearAccelZ);

        // Peak/valley for legacy step length estimation
        float totalMag = (float) Math.sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]);
        if (totalMag > peakAccel) peakAccel = totalMag;
        if (totalMag < valleyAccel) valleyAccel = totalMag;

        // Layer 1: Step detection via accelerometer periodicity
        detectStepFromAccel(totalMag, e.timestamp);

        // Layer 2: Integration + ZUPT
        if (integrationActive) {
            float dt = 0;
            if (lastIntegrationTime > 0) {
                dt = (e.timestamp - lastIntegrationTime) / 1e9f;
                if (dt > 0 && dt < 0.5f) {
                    // Integrate
                    velocity += linearMag * dt;
                    integratedDist += velocity * dt;
                    totalIntegrationTimeMs += (long)(dt * 1000);
                }
            }
            lastIntegrationTime = e.timestamp;

            // ZUPT: detect stationary
            updateZupt(totalMag);

            // Layer 3: Periodic ZUPT
            checkPeriodicZupt();
        }

        if (!useGameRV) updateOrientationFallback();
        if (callback != null) callback.onGravityUpdate(gravX, gravY, gravZ);
    }

    /** Step detection via peak finding on accelerometer magnitude.
     *  Works regardless of device orientation (pocket, bag, hand). */
    private void detectStepFromAccel(float mag, long timestamp) {
        // Update running mean
        runningMean = runningMean * (1 - MEAN_ALPHA) + mag * MEAN_ALPHA;

        // Store in circular buffer
        accelHistory[accelHistIdx] = mag;
        accelHistIdx = (accelHistIdx + 1) % accelHistory.length;
        if (accelHistCount < accelHistory.length) accelHistCount++;

        // Peak detection: crossing above mean + threshold
        boolean isAbove = mag > runningMean + PEAK_THRESHOLD;
        if (isAbove && !aboveMean) {
            // Rising edge - potential peak
            aboveMean = true;
        } else if (!isAbove && aboveMean) {
            // Falling edge - confirm peak
            aboveMean = false;
            long now = System.currentTimeMillis();
            long minInterval = 250; // ms, max ~4 steps/sec
            long maxInterval = 2000; // ms, min ~0.5 steps/sec

            if (lastPeakTime > 0) {
                long interval = now - lastPeakTime;
                if (interval > minInterval && interval < maxInterval) {
                    totalSteps++;
                    float dt = interval / 1000f;
                    float freq = 1f / dt;

                    // Estimate step length from frequency
                    lastStepLength = 0.4f + 0.35f * (freq - 1.5f);
                    lastStepLength = Math.max(0.35f, Math.min(1.3f, lastStepLength));

                    totalDistance = totalSteps * lastStepLength;
                    lastStepTime = now;

                    if (callback != null) callback.onStepUpdate(totalSteps, totalDistance, lastStepLength);

                    // Reset peak/valley for next step
                    peakAccel = 0;
                    valleyAccel = 100;
                }
            }
            lastPeakTime = now;
        }
    }

    /** ZUPT: Zero-velocity Update. Detect stationary and reset velocity. */
    private void updateZupt(float linearMag) {
        // Track variance of linear acceleration
        float diff = linearMag - zuptAccelVariance;
        zuptAccelVariance += diff * diff * 0.1f; // running variance estimate
        zuptSampleCount++;

        if (zuptSampleCount >= ZUPT_MIN_SAMPLES && zuptAccelVariance < ZUPT_VAR_THRESHOLD) {
            // Stationary detected - reset velocity
            velocity = 0;
            zuptSampleCount = 0;
            zuptAccelVariance = 0;
        }
    }

    /** Layer 3: Periodic forced ZUPT every 5 minutes. */
    private void checkPeriodicZupt() {
        long now = System.currentTimeMillis();
        if (lastPeriodicZuptTime == 0) {
            lastPeriodicZuptTime = now;
            return;
        }
        if (now - lastPeriodicZuptTime >= PERIODIC_ZUPT_INTERVAL_MS) {
            velocity = 0;
            lastPeriodicZuptTime = now;
        }
    }

    // === Gyroscope ===

    private void handleGyro(SensorEvent e) {
        if (useGameRV) return;
        if (!gyroInitialized) { gyroInitialized = true; lastGyroTime = e.timestamp; return; }
        float dt = (e.timestamp - lastGyroTime) / 1e9f;
        lastGyroTime = e.timestamp;
        if (dt <= 0 || dt > 0.5f) return;

        gyroAngle[0] += e.values[0] * dt;
        gyroAngle[1] += e.values[1] * dt;
        gyroAngle[2] += e.values[2] * dt;

        updateOrientationFallback();
    }

    // === Magnetometer ===

    private void handleMag(SensorEvent e) {
        if (useGameRV) return;
        geomag[0] = e.values[0]; geomag[1] = e.values[1]; geomag[2] = e.values[2];
        hasMag = true;
        updateOrientationFallback();
    }

    // === Gravity sensor ===

    private void handleGravitySensor(SensorEvent e) {
        gravity[0] = e.values[0];
        gravity[1] = e.values[1];
        gravity[2] = e.values[2];
        gravX = e.values[0] / GRAVITY;
        gravY = e.values[1] / GRAVITY;
        gravZ = e.values[2] / GRAVITY;
        if (callback != null) callback.onGravityUpdate(gravX, gravY, gravZ);
    }

    // === Orientation fallback ===

    private void updateOrientationFallback() {
        float newHeading;
        if (hasMag && accel != null) {
            float[] R = new float[9], I = new float[9];
            if (SensorManager.getRotationMatrix(R, I, gravity, geomag)) {
                float[] o = new float[3];
                SensorManager.getOrientation(R, o);
                newHeading = o[0];
            } else {
                newHeading = gyroAngle[2];
            }
        } else {
            newHeading = gyroAngle[2];
        }

        float newPitch = (float) Math.atan2(gravity[2], Math.sqrt(gravity[0] * gravity[0] + gravity[1] * gravity[1]));
        float newRoll = (float) Math.atan2(-gravity[0], gravity[2]);
        smoothOrientation(newHeading, newPitch, newRoll);
    }

    // === Orientation smoothing ===

    private void smoothOrientation(float newHeading, float newPitch, float newRoll) {
        if (!orientationInit) {
            smoothHeading = newHeading;
            smoothPitch = newPitch;
            smoothRoll = newRoll;
            targetHeading = newHeading;
            displayHeading = newHeading;
            orientationInit = true;
        } else {
            float headingDiff = newHeading - smoothHeading;
            while (headingDiff > Math.PI) headingDiff -= 2 * Math.PI;
            while (headingDiff < -Math.PI) headingDiff += 2 * Math.PI;

            float alpha = BASE_ALPHA + ADAPTIVE_FACTOR * Math.min(Math.abs(headingDiff) / (float) Math.PI, 1.0f);
            alpha = Math.min(alpha, 0.8f);

            smoothHeading += alpha * headingDiff;
            while (smoothHeading > Math.PI) smoothHeading -= 2 * Math.PI;
            while (smoothHeading < -Math.PI) smoothHeading += 2 * Math.PI;

            smoothPitch = 0.3f * smoothPitch + 0.7f * newPitch;
            smoothRoll = 0.3f * smoothRoll + 0.7f * newRoll;
        }

        targetHeading = smoothHeading;
        long now = SystemClock.elapsedRealtime();
        float dt = (now - lastUpdateTime) / 1000f;
        lastUpdateTime = now;

        if (dt > 0 && dt < 0.2f) {
            float diff = targetHeading - displayHeading;
            while (diff > Math.PI) diff -= 2 * Math.PI;
            while (diff < -Math.PI) diff += 2 * Math.PI;

            float maxStep = INTERP_SPEED * dt;
            if (Math.abs(diff) < maxStep) {
                displayHeading = targetHeading;
            } else {
                displayHeading += Math.signum(diff) * maxStep;
            }
            while (displayHeading > Math.PI) displayHeading -= 2 * Math.PI;
            while (displayHeading < -Math.PI) displayHeading += 2 * Math.PI;
        }

        if (callback != null) callback.onOrientationUpdate(displayHeading, smoothPitch, smoothRoll);
    }

    // === Public API ===

    /** Start integration tracking (call when recording starts) */
    public void startIntegration() {
        integrationActive = true;
        lastIntegrationTime = 0;
        lastPeriodicZuptTime = System.currentTimeMillis();
        velocity = 0;
    }

    /** Stop integration tracking (call when recording stops) */
    public void stopIntegration() {
        integrationActive = false;
    }

    /** Get combined distance: steps + integration with time correction */
    public float getCombinedDistance() {
        // Primary: step-based distance (more reliable when walking)
        if (totalSteps > 0 && lastStepTime > 0) {
            long timeSinceStep = System.currentTimeMillis() - lastStepTime;
            if (timeSinceStep < 5000) {
                // Walking recently, trust step distance
                return totalDistance;
            }
        }

        // Secondary: integration with time-based drift correction
        float driftCorrection = DRIFT_RATE * (totalIntegrationTimeMs / 1000f);
        float corrected = integratedDist - driftCorrection;
        return Math.max(corrected, 0);
    }

    public boolean isGameRVAvailable() { return gameRV != null; }
    public boolean isGyroAvailable() { return gyro != null; }
    public boolean isMagAvailable() { return mag != null; }
    public int getTotalSteps() { return totalSteps; }
    public float getTotalDistance() { return totalDistance; }
    public float getStepFrequency() {
        long now = System.currentTimeMillis();
        if (lastStepTime <= 0) return 0;
        float dt = (now - lastStepTime) / 1000f;
        return dt > 0 && dt < 3 ? 1f / dt : 0;
    }
    public float getGravX() { return gravX; }
    public float getGravY() { return gravY; }
    public float getGravZ() { return gravZ; }
    public float getRawAccelX() { return rawAccelX; }
    public float getRawAccelY() { return rawAccelY; }
    public float getRawAccelZ() { return rawAccelZ; }
    public long getTotalIntegrationTimeMs() { return totalIntegrationTimeMs; }
}
