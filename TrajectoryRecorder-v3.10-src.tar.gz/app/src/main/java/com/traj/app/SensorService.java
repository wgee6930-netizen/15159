package com.traj.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

public class SensorService extends Service {
    public static final String ACTION_DATA = "com.traj.app.SENSOR_DATA";
    public static final String ACTION_GPS_STATUS = "com.traj.app.GPS_STATUS";
    public static final String ACTION_GPS_TIMEOUT = "com.traj.app.GPS_TIMEOUT";
    public static final String CHANNEL_ID = "traj_rec";

    private PowerManager.WakeLock wakeLock;
    private SensorFusionManager sensorFusion;
    private boolean recording = false;
    private boolean foregroundStarted = false;
    private long startTime = 0;

    private boolean gpsEnabled = false;
    private float baseAltitude = 0;
    private float recordPrecisionM = 0.1f;

    private float totalDist = 0, totalAsc = 0;
    private float lastRecordedDist = -1;

    private float heading, pitch, roll;
    private int steps;
    private float sensorDist;

    // GPS
    private LocationManager locationManager;
    private Location startLocation;
    private float startLat, startLon;
    private boolean gpsFixed = false;
    private int gpsAccuracyLevel = 0; // 0=3m, 1=5m, 2=10m
    private static final float[] GPS_ACCURACY_LEVELS = {3.0f, 5.0f, 10.0f};
    private static final long GPS_TIMEOUT_MS = 15000; // 15 seconds per level
    private float bestAccuracy = Float.MAX_VALUE;
    private Location bestLocation = null;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable gpsTimeoutRunnable;
    private String gpsStatus = "";

    // Broadcast sensor data every 100ms for smooth compass
    private final Runnable sensorTicker = new Runnable() {
        @Override public void run() {
            broadcastSensorData();
            handler.postDelayed(this, 100);
        }
    };

    // Recording tick (distance/altitude tracking)
    private final Runnable recordTicker = new Runnable() {
        @Override public void run() {
            if (!recording) return;
            trackRecording();
            handler.postDelayed(this, 500);
        }
    };

    private final IBinder binder = new LocalBinder();
    public class LocalBinder extends Binder {
        public SensorService getService() { return SensorService.this; }
    }

    @Override
    public IBinder onBind(Intent i) { return binder; }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();

        sensorFusion = new SensorFusionManager(this);
        sensorFusion.start(new SensorFusionManager.FusionCallback() {
            @Override public void onOrientationUpdate(float h, float p, float r) {
                heading = h; pitch = p; roll = r;
            }
            @Override public void onStepUpdate(int s, float d, float l) {
                steps = s; sensorDist = d;
            }
            @Override public void onGravityUpdate(float gx, float gy, float gz) {}
            @Override public void onAccuracyChanged(int a) {}
        });

        handler.post(sensorTicker);
    }

    /** Broadcast current sensor data to activity */
    private void broadcastSensorData() {
        float dist = recording ? totalDist : 0f;
        Intent i = new Intent(ACTION_DATA);
        i.putExtra("dist", dist);
        i.putExtra("asc", recording ? totalAsc : 0f);
        i.putExtra("steps", steps);
        i.putExtra("heading", heading);
        i.putExtra("pitch", pitch);
        i.putExtra("roll", roll);
        i.putExtra("altitude", recording ? baseAltitude + totalAsc : baseAltitude);
        i.putExtra("speed", recording && sensorFusion != null ? sensorFusion.getStepFrequency() * 0.72f : 0f);
        i.putExtra("elapsed", recording ? System.currentTimeMillis() - startTime : 0L);
        i.putExtra("lat", gpsFixed ? startLat : 0f);
        i.putExtra("lon", gpsFixed ? startLon : 0f);
        i.putExtra("startLat", gpsFixed ? startLat : 0f);
        i.putExtra("startLon", gpsFixed ? startLon : 0f);
        i.putExtra("gravX", sensorFusion != null ? sensorFusion.getGravX() : 0);
        i.putExtra("gravY", sensorFusion != null ? sensorFusion.getGravY() : 0);
        i.putExtra("gravZ", sensorFusion != null ? sensorFusion.getGravZ() : 1);
        i.putExtra("accelX", sensorFusion != null ? sensorFusion.getRawAccelX() : 0);
        i.putExtra("accelY", sensorFusion != null ? sensorFusion.getRawAccelY() : 0);
        i.putExtra("accelZ", sensorFusion != null ? sensorFusion.getRawAccelZ() : 0);
        i.putExtra("recording", recording);
        sendBroadcast(i);
    }

    /** Track distance/altitude while recording */
    private void trackRecording() {
        // Use combined distance from SensorFusionManager (triple protection)
        if (sensorFusion != null) {
            totalDist = sensorFusion.getCombinedDistance();
        }
        steps = sensorFusion != null ? sensorFusion.getTotalSteps() : 0;

        float da = (float) Math.sin(pitch) * (totalDist - (lastRecordedDist >= 0 ? lastRecordedDist : 0));
        if (Math.abs(da) < 5 && Math.abs(da) > 0.05f) totalAsc += da;
        lastRecordedDist = totalDist;

        // Lat/lon: sensor-based relative movement
        float latVal = (float) (totalDist * Math.cos(heading));
        float lonVal = (float) (totalDist * Math.sin(heading));

        Intent i = new Intent(ACTION_DATA);
        i.putExtra("dist", totalDist);
        i.putExtra("asc", totalAsc);
        i.putExtra("steps", steps);
        i.putExtra("heading", heading);
        i.putExtra("pitch", pitch);
        i.putExtra("roll", roll);
        i.putExtra("altitude", baseAltitude + totalAsc);
        i.putExtra("speed", sensorFusion != null ? sensorFusion.getStepFrequency() * 0.72f : 0f);
        i.putExtra("elapsed", System.currentTimeMillis() - startTime);
        i.putExtra("lat", latVal);
        i.putExtra("lon", lonVal);
        i.putExtra("startLat", gpsFixed ? startLat : 0f);
        i.putExtra("startLon", gpsFixed ? startLon : 0f);
        i.putExtra("gravX", sensorFusion != null ? sensorFusion.getGravX() : 0);
        i.putExtra("gravY", sensorFusion != null ? sensorFusion.getGravY() : 0);
        i.putExtra("gravZ", sensorFusion != null ? sensorFusion.getGravZ() : 1);
        i.putExtra("accelX", sensorFusion != null ? sensorFusion.getRawAccelX() : 0);
        i.putExtra("accelY", sensorFusion != null ? sensorFusion.getRawAccelY() : 0);
        i.putExtra("accelZ", sensorFusion != null ? sensorFusion.getRawAccelZ() : 0);
        i.putExtra("recording", true);
        sendBroadcast(i);
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        return START_STICKY;
    }

    public void applySettings(boolean gps, float baseAlt, int precisionIdx) {
        this.gpsEnabled = gps;
        this.baseAltitude = baseAlt;
        switch (precisionIdx) {
            case 0: recordPrecisionM = 0.1f; break;
            case 1: recordPrecisionM = 0.5f; break;
            case 2: recordPrecisionM = 1.0f; break;
        }
        if (gpsEnabled) startGpsWithFallback();
    }

    // === GPS with timeout + accuracy fallback ===

    private void startGpsWithFallback() {
        gpsAccuracyLevel = 0;
        bestAccuracy = Float.MAX_VALUE;
        bestLocation = null;
        startGpsForLevel();
    }

    private void startGpsForLevel() {
        float requiredAccuracy = GPS_ACCURACY_LEVELS[gpsAccuracyLevel];
        gpsStatus = "定位中…(" + (int)requiredAccuracy + "m)";
        broadcastGpsStatus(gpsStatus);

        try {
            if (locationManager == null) {
                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                1000, 0, gpsListener, Looper.getMainLooper());
        } catch (SecurityException e) {
            gpsEnabled = false;
            gpsStatus = "无定位权限";
            broadcastGpsStatus(gpsStatus);
            return;
        }

        // Set timeout
        if (gpsTimeoutRunnable != null) handler.removeCallbacks(gpsTimeoutRunnable);
        gpsTimeoutRunnable = () -> onGpsTimeout();
        handler.postDelayed(gpsTimeoutRunnable, GPS_TIMEOUT_MS);
    }

    private void onGpsTimeout() {
        float requiredAccuracy = GPS_ACCURACY_LEVELS[gpsAccuracyLevel];

        // Check if we have a location within current accuracy level
        if (bestLocation != null && bestAccuracy <= requiredAccuracy) {
            // Accept this location
            acceptLocation(bestLocation);
            return;
        }

        // Try next accuracy level
        if (gpsAccuracyLevel < GPS_ACCURACY_LEVELS.length - 1) {
            gpsAccuracyLevel++;
            float newAccuracy = GPS_ACCURACY_LEVELS[gpsAccuracyLevel];
            gpsStatus = "精度不足，尝试" + (int)newAccuracy + "m…";
            broadcastGpsStatus(gpsStatus);

            // Check if best location meets new threshold
            if (bestLocation != null && bestAccuracy <= newAccuracy) {
                acceptLocation(bestLocation);
                return;
            }

            // Reset timeout for next level
            handler.postDelayed(gpsTimeoutRunnable, GPS_TIMEOUT_MS);
        } else {
            // All levels exhausted - notify activity for dialog
            stopGps();
            gpsStatus = "GPS超时";
            broadcastGpsStatus(gpsStatus);
            broadcastGpsTimeout();
        }
    }

    private void acceptLocation(Location loc) {
        gpsFixed = true;
        startLocation = loc;
        startLat = (float) loc.getLatitude();
        startLon = (float) loc.getLongitude();
        stopGps();
        if (gpsTimeoutRunnable != null) handler.removeCallbacks(gpsTimeoutRunnable);

        gpsStatus = "已锁定(" + (int)bestAccuracy + "m)";
        broadcastGpsStatus(gpsStatus);
    }

    private void startGps() {
        try {
            if (locationManager == null) {
                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                1000, 0, gpsListener, Looper.getMainLooper());
        } catch (SecurityException e) {
            gpsEnabled = false;
        }
    }

    private void stopGps() {
        if (locationManager != null) {
            try { locationManager.removeUpdates(gpsListener); } catch (Exception ignored) {}
        }
    }

    /** Called when user clicks "wait" on timeout dialog */
    public void continueGpsWait() {
        if (gpsFixed) return;
        // Reset to level 0 and start over
        startGpsWithFallback();
    }

    /** Called when user clicks "cancel" on timeout dialog */
    public void cancelGps() {
        stopGps();
        if (gpsTimeoutRunnable != null) handler.removeCallbacks(gpsTimeoutRunnable);
        gpsEnabled = false;
        gpsStatus = "已跳过";
        broadcastGpsStatus(gpsStatus);
    }

    private final LocationListener gpsListener = new LocationListener() {
        @Override public void onLocationChanged(Location loc) {
            if (gpsFixed) return;

            float acc = loc.getAccuracy();
            if (acc < bestAccuracy) {
                bestAccuracy = acc;
                bestLocation = loc;
            }

            // Check if meets current level threshold
            float requiredAccuracy = GPS_ACCURACY_LEVELS[gpsAccuracyLevel];
            if (acc <= requiredAccuracy) {
                acceptLocation(loc);
            }

            gpsStatus = "定位中…(" + String.format("%.1f", acc) + "m)";
            broadcastGpsStatus(gpsStatus);
        }
        @Override public void onStatusChanged(String s, int i, Bundle b) {}
        @Override public void onProviderEnabled(String s) {}
        @Override public void onProviderDisabled(String s) {}
    };

    // === Broadcasts ===

    private void broadcastGpsStatus(String status) {
        Intent i = new Intent(ACTION_GPS_STATUS);
        i.putExtra("status", status);
        i.putExtra("fixed", gpsFixed);
        sendBroadcast(i);
    }

    private void broadcastGpsTimeout() {
        Intent i = new Intent(ACTION_GPS_TIMEOUT);
        i.putExtra("level", gpsAccuracyLevel);
        sendBroadcast(i);
    }

    // === Recording ===

    public void startRecording() {
        if (recording) return;
        recording = true;
        startTime = System.currentTimeMillis();
        totalDist = 0; totalAsc = 0;
        lastRecordedDist = -1;
        sensorFusion.reset();
        sensorFusion.startIntegration();

        if (!foregroundStarted) {
            createChannel();
            startForeground(1, buildNotif(getString(R.string.recording)));
            foregroundStarted = true;
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "traj:rec");
            wakeLock.acquire();
        }

        handler.post(recordTicker);
    }

    public void stopRecording() {
        recording = false;
        handler.removeCallbacks(recordTicker);
        if (sensorFusion != null) sensorFusion.stopIntegration();
        stopGps();
        if (gpsTimeoutRunnable != null) handler.removeCallbacks(gpsTimeoutRunnable);
    }

    public boolean isRecording() { return recording; }

    public String getGpsStatus() { return gpsStatus; }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(sensorTicker);
        handler.removeCallbacks(recordTicker);
        if (gpsTimeoutRunnable != null) handler.removeCallbacks(gpsTimeoutRunnable);
        if (sensorFusion != null) sensorFusion.stop();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (foregroundStarted) stopForeground(true);
        super.onDestroy();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, getString(R.string.app_name),
                NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotif(String text) {
        Notification.Builder nb = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);
        return nb.setContentTitle(getString(R.string.app_name)).setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true).build();
    }
}
