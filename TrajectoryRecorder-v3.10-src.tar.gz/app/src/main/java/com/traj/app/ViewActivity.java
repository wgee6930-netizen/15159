package com.traj.app;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ViewActivity extends BaseActivity {
    private DbHelper db;
    private Route route;
    private ProfileView profileView;
    private TrajView3D trajView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyBaseLocale();
        applyFullScreen();
        setContentView(R.layout.activity_view);

        db = new DbHelper(this);
        long id = getIntent().getLongExtra("routeId", -1);
        route = db.getById(id);
        if (route == null) { finish(); return; }

        profileView = findViewById(R.id.profileView);
        trajView = findViewById(R.id.trajView);

        TextView title = findViewById(R.id.tvViewTitle);
        title.setText(route.name != null ? route.name : getString(R.string.route_name));

        ((TextView) findViewById(R.id.tvVDist)).setText(fmtDist(route.totalDist));
        ((TextView) findViewById(R.id.tvVLevel)).setText(
            (route.totalAsc >= 0 ? "+" : "") + String.format(Locale.US, "%.1f", route.totalAsc) + "m");
        ((TextView) findViewById(R.id.tvVDur)).setText(fmtDur(route.duration));

        profileView.setRoute(route);
        trajView.setRoute(route);

        findViewById(R.id.btnGear2).setOnClickListener(v -> showSettings());
    }

    private void showSettings() {
        String[] opts = {
            getString(R.string.calibration),
            getString(R.string.export_gpx),
            getString(R.string.export_kml),
            getString(R.string.export_csv)
        };
        new AlertDialog.Builder(this)
            .setTitle(R.string.settings)
            .setItems(opts, (d, w) -> {
                switch (w) {
                    case 0: showCalibration(); break;
                    case 1: exportGpx(); break;
                    case 2: exportKml(); break;
                    case 3: exportCsv(); break;
                }
            })
            .show();
    }

    private void showCalibration() {
        EditText input = new EditText(this);
        input.setText(String.valueOf(route.altOff));
        input.setTextColor(Color.parseColor("#E6EDF3"));
        input.setHintTextColor(Color.parseColor("#484F58"));
        LinearLayout lay = new LinearLayout(this);
        lay.setPadding(48, 16, 48, 0);
        lay.addView(input);

        new AlertDialog.Builder(this)
            .setTitle(R.string.calibration)
            .setView(lay)
            .setPositiveButton(R.string.ok, (d, w) -> {
                try {
                    route.altOff = Float.parseFloat(input.getText().toString());
                    db.update(route);
                    profileView.setRoute(route);
                    trajView.setRoute(route);
                } catch (Exception ignored) {}
            })
            .setNeutralButton(R.string.reset_alt, (d, w) -> {
                route.altOff = route.origAltOff;
                db.update(route);
                profileView.setRoute(route);
                trajView.setRoute(route);
            })
            .show();
    }

    private void exportGpx() {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\"?>\n<gpx version=\"1.1\">\n<trk><name>")
          .append(route.name != null ? route.name : "route")
          .append("</name><trkseg>\n");
        for (Route.Point p : route.pts) {
            sb.append(String.format(Locale.US,
                "<trkpt lat=\"%.6f\" lon=\"%.6f\"><ele>%.1f</ele></trkpt>\n",
                p.lat, p.lon, p.a + route.altOff));
        }
        sb.append("</trkseg></trk></gpx>");
        saveToFile("gpx", sb.toString());
    }

    private void exportKml() {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\"?>\n<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n<Document>\n<name>")
          .append(route.name != null ? route.name : "route")
          .append("</name>\n<Placemark>\n<LineString>\n<coordinates>\n");
        for (Route.Point p : route.pts) {
            sb.append(String.format(Locale.US, "%.6f,%.6f,%.1f\n", p.lon, p.lat, p.a + route.altOff));
        }
        sb.append("</coordinates>\n</LineString>\n</Placemark>\n</Document>\n</kml>");
        saveToFile("kml", sb.toString());
    }

    private void exportCsv() {
        StringBuilder sb = new StringBuilder("distance_m,altitude_m,speed_kmh,lat,lon\n");
        for (Route.Point p : route.pts) {
            sb.append(String.format(Locale.US, "%.1f,%.1f,%.2f,%.6f,%.6f\n",
                p.x, p.a + route.altOff, p.sp, p.lat, p.lon));
        }
        saveToFile("csv", sb.toString());
    }

    private void saveToFile(String ext, String content) {
        try {
            SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
            String fileName = route.name != null ? route.name : "route";
            fileName = fileName.replaceAll("[^a-zA-Z0-9\\u4e00-\\u9fff_-]", "_");
            fileName += "_" + df.format(new Date()) + "." + ext;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+: use MediaStore
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, getMimeType(ext));
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    OutputStream os = getContentResolver().openOutputStream(uri);
                    if (os != null) {
                        os.write(content.getBytes("UTF-8"));
                        os.close();
                        Toast.makeText(this, getString(R.string.export_success, fileName), Toast.LENGTH_LONG).show();
                    }
                }
            } else {
                // Legacy: write to Downloads directory
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                File file = new File(dir, fileName);
                FileWriter fw = new FileWriter(file);
                fw.write(content);
                fw.close();
                Toast.makeText(this, getString(R.string.export_success, file.getAbsolutePath()), Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.export_fail, e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    private String getMimeType(String ext) {
        switch (ext) {
            case "gpx": return "application/gpx+xml";
            case "kml": return "application/vnd.google-earth.kml+xml";
            case "csv": return "text/csv";
            default: return "application/octet-stream";
        }
    }

    private String fmtDist(float m) {
        if (m >= 10000) return String.format(Locale.US, "%.1fkm", m / 1000);
        if (m >= 1000) return String.format(Locale.US, "%.2fkm", m / 1000);
        return String.format(Locale.US, "%.1fm", m);
    }

    private String fmtDur(long ms) {
        long s = ms / 1000, h = s / 3600, m = (s % 3600) / 60, sc = s % 60;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, sc);
        return String.format("%d:%02d", m, sc);
    }
}
