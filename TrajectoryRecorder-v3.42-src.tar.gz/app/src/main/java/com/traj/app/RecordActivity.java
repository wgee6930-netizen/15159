package com.traj.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RecordActivity extends BaseActivity {
    private static final int PERM_REQUEST = 100;

    private SensorService sensorService;
    private boolean bound = false;
    private BroadcastReceiver receiver;

    private CompassView compassView;
    private CalibrationView calibrationView;
    private TextView tvTime, tvSpeed, tvDist, tvLevel, tvAlt;
    private TextView tvAccelX, tvAccelY, tvAccelZ;
    private TextView tvGpsStatus;
    private FrameLayout btnPause;
    private LinearLayout btnCancel, btnResume, btnSave;
    private LinearLayout pauseButtonsContainer;

    private enum State { IDLE, CALIBRATING, SETTINGS, RECORDING, PAUSED, SAVE_SHOWN }
    private State state = State.IDLE;

    private long recT0 = 0;
    private float recDist = 0, recAsc = 0, baseAltitude = 0;
    private List<Route.Point> pts = new ArrayList<>();
    private float heading = 0, pitch = 0, roll = 0, altitude = 0, speed = 0;
    private float gravX = 0, gravY = 0, gravZ = 1;
    private float lat = 0, lon = 0;


    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable compassUpdater;
    private Runnable calibrationTimeout;

    private float precisionM = 0.1f;
    private float lastRecordedDist = -1;
    private boolean gpsEnabled = false;
    private boolean deviceCalibrated = false;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { sensorService = ((SensorService.LocalBinder) b).getService(); bound = true; }
        @Override public void onServiceDisconnected(ComponentName n) { sensorService = null; bound = false; }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyBaseLocale();
        applyFullScreen();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_record);

        compassView = findViewById(R.id.compassView);
        calibrationView = findViewById(R.id.calibrationView);
        tvTime = findViewById(R.id.tvTime);
        tvSpeed = findViewById(R.id.tvSpeed);
        tvDist = findViewById(R.id.tvDist);
        tvLevel = findViewById(R.id.tvLevel);
        tvAlt = findViewById(R.id.tvAlt);
        tvAccelX = findViewById(R.id.tvAccelX);
        tvAccelY = findViewById(R.id.tvAccelY);
        tvAccelZ = findViewById(R.id.tvAccelZ);
        btnPause = findViewById(R.id.btnPause);
        btnCancel = findViewById(R.id.btnCancel);
        btnResume = findViewById(R.id.btnResume);
        btnSave = findViewById(R.id.btnSave);

        // GPS status text below compass
        tvGpsStatus = new TextView(this);
        tvGpsStatus.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 11);
        tvGpsStatus.setTextColor(Color.parseColor("#484F58"));
        tvGpsStatus.setGravity(Gravity.CENTER);
        tvGpsStatus.setPadding(0, dp(4), 0, 0);

        // Insert GPS status text after compassView
        ViewGroup compassParent = (ViewGroup) compassView.getParent();
        int compassIdx = compassParent.indexOfChild(compassView);
        compassParent.addView(tvGpsStatus, compassIdx + 1);

        // Pause buttons container - centered with doubled spacing
        pauseButtonsContainer = new LinearLayout(this);
        pauseButtonsContainer.setOrientation(LinearLayout.HORIZONTAL);
        pauseButtonsContainer.setGravity(Gravity.CENTER);
        pauseButtonsContainer.setVisibility(View.GONE);

        SharedPreferences prefs = getSharedPreferences("traj", MODE_PRIVATE);
        deviceCalibrated = prefs.getBoolean("calibrated", false);

        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent i) {
                String action = i.getAction();
                if (SensorService.ACTION_DATA.equals(action)) {
                    handleSensorData(i);
                } else if (SensorService.ACTION_GPS_STATUS.equals(action)) {
                    String status = i.getStringExtra("status");
                    if (status != null && tvGpsStatus != null) {
                        tvGpsStatus.setText(status);
                    }
                } else if (SensorService.ACTION_GPS_TIMEOUT.equals(action)) {
                    showGpsTimeoutDialog();
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(SensorService.ACTION_DATA);
        filter.addAction(SensorService.ACTION_GPS_STATUS);
        filter.addAction(SensorService.ACTION_GPS_TIMEOUT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, filter);

        btnPause.setOnClickListener(v -> { if (state == State.RECORDING) doPause(); });
        btnCancel.setOnClickListener(v -> doCancel());
        btnResume.setOnClickListener(v -> doResume());
        btnSave.setOnClickListener(v -> doSave());
        findViewById(R.id.btnCalibrate).setOnClickListener(v -> toggleCalibration());

        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission("android.permission.HIGH_SAMPLING_RATE_SENSORS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.HIGH_SAMPLING_RATE_SENSORS"}, PERM_REQUEST);
        } else {
            initService();
        }
    }

    private void handleSensorData(Intent i) {
        heading = i.getFloatExtra("heading", 0);
        pitch = i.getFloatExtra("pitch", 0);
        roll = i.getFloatExtra("roll", 0);
        gravX = i.getFloatExtra("gravX", 0);
        gravY = i.getFloatExtra("gravY", 0);
        gravZ = i.getFloatExtra("gravZ", 1);
        float ax = i.getFloatExtra("accelX", 0);
        float ay = i.getFloatExtra("accelY", 0);
        float az = i.getFloatExtra("accelZ", 0);
        tvAccelX.setText(String.format(Locale.US, "%.2f", ax));
        tvAccelY.setText(String.format(Locale.US, "%.2f", ay));
        tvAccelZ.setText(String.format(Locale.US, "%.2f", az));
        boolean isRec = i.getBooleanExtra("recording", false);
        if (isRec) {
            recDist = i.getFloatExtra("dist", 0);
            recAsc = i.getFloatExtra("asc", 0);
            altitude = i.getFloatExtra("altitude", 0);
            speed = i.getFloatExtra("speed", 0);
            lat = i.getFloatExtra("lat", 0);
            lon = i.getFloatExtra("lon", 0);
            long elapsed = i.getLongExtra("elapsed", 0);
            if (recDist - lastRecordedDist >= precisionM || lastRecordedDist < 0) {
                pts.add(new Route.Point(recDist, altitude, speed * 3.6f, lat, lon));
                lastRecordedDist = recDist;
            }
            tvTime.setText(fmtDur(elapsed));
            tvDist.setText(fmtDist(recDist));
            tvSpeed.setText(String.format(Locale.US, "%.1fkm/h", speed * 3.6f));
            tvLevel.setText(String.format(Locale.US, "%+.1fm", recAsc));
            tvAlt.setText(String.format(Locale.US, "%.1fm", altitude));
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] p, int[] r) { initService(); }

    private void initService() {
        Intent svc = new Intent(this, SensorService.class);
        startService(svc);
        bindService(svc, conn, Context.BIND_AUTO_CREATE);
        startCompassLoop();
        if (!deviceCalibrated) showCalibrationFirst(); else showSettingsDialog();
    }

    // === GPS Timeout Dialog ===

    private void showGpsTimeoutDialog() {
        if (isFinishing() || isDestroyed()) return;
        int nextLevel = 0;
        if (bound && sensorService != null) {
            // Determine what level we're at from the status
            String status = sensorService.getGpsStatus();
        }

        new AlertDialog.Builder(this, R.style.DarkDialog)
            .setTitle("GPS定位超时")
            .setMessage("无法获取GPS信号，是否继续等待？")
            .setCancelable(false)
            .setNegativeButton("取消", (d, w) -> {
                if (bound) sensorService.cancelGps();
                d.dismiss();
            })
            .setPositiveButton("等待", (d, w) -> {
                if (bound) sensorService.continueGpsWait();
                d.dismiss();
            })
            .show();
    }

    // === Flow ===

    private void showCalibrationFirst() {
        state = State.CALIBRATING;
        calibrationView.setVisibility(View.VISIBLE);
        calibrationView.startCalibration();
        // Poll until calibration completes — no skip, no timeout
        calibrationTimeout = new Runnable() {
            @Override public void run() {
                if (calibrationView.isCompleted()) {
                    finishCalibration();
                } else {
                    handler.postDelayed(this, 200);
                }
            }
        };
        handler.postDelayed(calibrationTimeout, 200);
    }

    private void finishCalibration() {
        calibrationView.stopCalibration(); calibrationView.setVisibility(View.GONE);
        getSharedPreferences("traj", MODE_PRIVATE).edit().putBoolean("calibrated", true).apply();
        deviceCalibrated = true;
        showSettingsDialog();
    }

    private void toggleCalibration() {
        if (calibrationView.getVisibility() == View.VISIBLE) { calibrationView.stopCalibration(); calibrationView.setVisibility(View.GONE); }
        else { calibrationView.setVisibility(View.VISIBLE); calibrationView.startCalibration(); }
    }

    // === Settings Dialog ===

    private void showSettingsDialog() {
        if (isFinishing() || isDestroyed()) return;
        state = State.SETTINGS;
        SharedPreferences prefs = getSharedPreferences("traj", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#161B22"));
        root.setPadding(dp(20), dp(16), dp(20), dp(8));

        root.addView(text(getString(R.string.record_settings), 16, "#E6EDF3", Typeface.BOLD, 0, 0, 0, dp(12)));
        root.addView(line());

        // Precision
        root.addView(text(getString(R.string.precision), 13, "#8B949E", Typeface.NORMAL, 0, dp(10), 0, dp(6)));
        RadioGroup rg = new RadioGroup(this); rg.setOrientation(RadioGroup.VERTICAL);
        RadioButton rb01 = radio(getString(R.string.precision_01));
        RadioButton rb05 = radio(getString(R.string.precision_05));
        RadioButton rb1 = radio(getString(R.string.precision_1));
        rg.addView(rb01); rg.addView(rb05); rg.addView(rb1);
        int pi = prefs.getInt("precision", 0);
        (pi == 1 ? rb05 : pi == 2 ? rb1 : rb01).setChecked(true);
        root.addView(rg);

        root.addView(line());

        // GPS toggle
        LinearLayout gpsRow = new LinearLayout(this);
        gpsRow.setOrientation(LinearLayout.HORIZONTAL);
        gpsRow.setGravity(Gravity.CENTER_VERTICAL);
        gpsRow.setPadding(0, dp(10), 0, dp(4));
        TextView lbl = text(getString(R.string.gps_enable), 14, "#E6EDF3", Typeface.NORMAL, 0, 0, 0, 0);
        lbl.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        gpsRow.addView(lbl);

        final boolean[] gpsState = {false};
        TextView toggle = new TextView(this);
        toggle.setPadding(dp(16), dp(6), dp(16), dp(6));
        toggle.setGravity(Gravity.CENTER);
        toggle.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 13);
        toggle.setTypeface(null, Typeface.BOLD);
        Runnable updateToggle = () -> {
            if (gpsState[0]) {
                toggle.setText("ON");
                toggle.setTextColor(Color.parseColor("#000000"));
                toggle.setBackgroundColor(Color.parseColor("#00D4FF"));
            } else {
                toggle.setText("OFF");
                toggle.setTextColor(Color.parseColor("#8B949E"));
                toggle.setBackgroundColor(Color.parseColor("#30363D"));
            }
        };
        toggle.setOnClickListener(v -> { gpsState[0] = !gpsState[0]; updateToggle.run(); });
        updateToggle.run();
        gpsRow.addView(toggle);
        root.addView(gpsRow);
        root.addView(text(getString(R.string.gps_desc), 11, "#484F58", Typeface.NORMAL, 0, 0, 0, dp(4)));

        root.addView(line());

        // Altitude
        root.addView(text(getString(R.string.base_altitude), 13, "#8B949E", Typeface.NORMAL, 0, dp(10), 0, dp(6)));
        EditText etAlt = new EditText(this);
        etAlt.setHint(getString(R.string.base_altitude_hint));
        etAlt.setTextColor(Color.parseColor("#E6EDF3"));
        etAlt.setHintTextColor(Color.parseColor("#484F58"));
        etAlt.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 14);
        etAlt.setTypeface(Typeface.MONOSPACE);
        etAlt.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        etAlt.setSingleLine(true);
        etAlt.setFocusable(true);
        etAlt.setFocusableInTouchMode(true);
        etAlt.setBackground(makeInputBg());
        etAlt.setPadding(dp(12), dp(10), dp(12), dp(10));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) etAlt.setTextCursorDrawable(android.R.color.white);
        float sa = prefs.getFloat("baseAlt", 0);
        if (sa != 0) etAlt.setText(String.valueOf(sa));
        root.addView(etAlt);

        root.addView(line());

        // Buttons
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.END);
        btnRow.setPadding(0, dp(10), 0, 0);
        TextView bCancel = btn(getString(R.string.cancel), "#8B949E");
        TextView bOk = btn(getString(R.string.ok), "#00D4FF");
        btnRow.addView(bCancel); btnRow.addView(spacer(dp(20), 0)); btnRow.addView(bOk);
        root.addView(btnRow);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);

        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.DarkDialog);
        builder.setView(sv);
        AlertDialog dialog = builder.create();
        dialog.setCancelable(false);
        dialog.show();

        bCancel.setOnClickListener(v -> { dialog.dismiss(); finish(); });
        bOk.setOnClickListener(v -> {
            dialog.dismiss();
            SharedPreferences.Editor ed = prefs.edit();
            int prec = rb05.isChecked() ? 1 : rb1.isChecked() ? 2 : 0;
            ed.putInt("precision", prec);
            ed.putBoolean("gps", gpsState[0]);
            try { ed.putFloat("baseAlt", Float.parseFloat(etAlt.getText().toString())); } catch (Exception e) { ed.putFloat("baseAlt", 0); }
            ed.apply();
            precisionM = prec == 1 ? 0.5f : prec == 2 ? 1.0f : 0.1f;
            gpsEnabled = gpsState[0];
            try { baseAltitude = Float.parseFloat(etAlt.getText().toString()); } catch (Exception e) { baseAltitude = 0; }
            if (gpsEnabled && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERM_REQUEST + 1);
                return;
            }
            startRecordingFlow();
        });
    }

    // === UI Helpers ===

    private TextView text(String s, int sp, String color, int style, int l, int t, int r, int b) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, sp); v.setTextColor(Color.parseColor(color));
        v.setTypeface(null, style); v.setPadding(l, t, r, b);
        return v;
    }

    private RadioButton radio(String s) {
        RadioButton r = new RadioButton(this);
        r.setText(s); r.setTextColor(Color.parseColor("#E6EDF3")); r.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 14);
        return r;
    }

    private TextView btn(String s, String color) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 15); v.setTextColor(Color.parseColor(color));
        v.setTypeface(null, Typeface.BOLD); v.setPadding(dp(16), dp(8), dp(16), dp(8));
        return v;
    }

    private View line() {
        View v = new View(this);
        v.setBackgroundColor(Color.parseColor("#30363D"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1);
        lp.topMargin = dp(8); lp.bottomMargin = dp(8);
        v.setLayoutParams(lp);
        return v;
    }

    private View spacer(int w, int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(w, h));
        return v;
    }

    private android.graphics.drawable.Drawable makeInputBg() {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(Color.parseColor("#0d1117"));
        d.setStroke(1, Color.parseColor("#30363D"));
        d.setCornerRadius(dp(6));
        return d;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    // === Recording ===

    private void startRecordingFlow() {
        if (bound) sensorService.applySettings(gpsEnabled, baseAltitude, precisionM == 0.1f ? 0 : precisionM == 0.5f ? 1 : 2);
        state = State.RECORDING;
        recT0 = System.currentTimeMillis(); pts.clear(); recDist = 0; recAsc = 0; lastRecordedDist = -1;
        if (bound) sensorService.startRecording();
        btnPause.setVisibility(View.VISIBLE);
        btnCancel.setVisibility(View.GONE); btnResume.setVisibility(View.GONE); btnSave.setVisibility(View.GONE);
    }

    private void doPause() {
        state = State.PAUSED;
        if (bound) sensorService.stopRecording();
        btnPause.setVisibility(View.GONE);
        // Show centered pause buttons with doubled spacing
        showPauseButtons();
    }

    private void doResume() {
        state = State.RECORDING;
        hidePauseButtons();
        if (bound) sensorService.startRecording();
        btnPause.setVisibility(View.VISIBLE);
    }

    private void doCancel() {
        hidePauseButtons();
        if (bound) sensorService.stopRecording();
        finish();
    }

    private void showPauseButtons() {
        // Find the parent layout that contains the pause button
        View parent = (View) btnPause.getParent();
        if (parent instanceof LinearLayout) {
            LinearLayout parentLayout = (LinearLayout) parent;

            // Remove container from its current parent if already attached
            if (pauseButtonsContainer.getParent() != null) {
                ((ViewGroup) pauseButtonsContainer.getParent()).removeView(pauseButtonsContainer);
            }

            // Remove buttons from their current parents
            if (btnCancel.getParent() != null) ((ViewGroup) btnCancel.getParent()).removeView(btnCancel);
            if (btnResume.getParent() != null) ((ViewGroup) btnResume.getParent()).removeView(btnResume);
            if (btnSave.getParent() != null) ((ViewGroup) btnSave.getParent()).removeView(btnSave);

            // Create centered container with doubled spacing
            pauseButtonsContainer.removeAllViews();
            pauseButtonsContainer.setVisibility(View.VISIBLE);

            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

            btnCancel.setLayoutParams(btnParams);
            btnResume.setLayoutParams(btnParams);
            btnSave.setLayoutParams(btnParams);

            // Spacers for doubled spacing
            View spacer1 = new View(this);
            spacer1.setLayoutParams(new LinearLayout.LayoutParams(dp(40), 0));
            View spacer2 = new View(this);
            spacer2.setLayoutParams(new LinearLayout.LayoutParams(dp(40), 0));

            pauseButtonsContainer.addView(btnCancel);
            pauseButtonsContainer.addView(spacer1);
            pauseButtonsContainer.addView(btnResume);
            pauseButtonsContainer.addView(spacer2);
            pauseButtonsContainer.addView(btnSave);

            btnCancel.setVisibility(View.VISIBLE);
            btnResume.setVisibility(View.VISIBLE);
            btnSave.setVisibility(View.VISIBLE);

            // Add container to parent at the position of the pause button
            int pauseIdx = parentLayout.indexOfChild(btnPause);
            parentLayout.addView(pauseButtonsContainer, pauseIdx);
        }
    }

    private void hidePauseButtons() {
        if (pauseButtonsContainer != null) {
            pauseButtonsContainer.setVisibility(View.GONE);
        }
    }

    private void doSave() {
        if (isFinishing() || isDestroyed()) return;
        hidePauseButtons();
        if (bound) sensorService.stopRecording();
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setBackgroundColor(Color.parseColor("#161B22"));
        c.setPadding(dp(20), dp(16), dp(20), dp(8));
        c.addView(text(getString(R.string.cumulative_distance, fmtDist(recDist)), 12, "#484F58", Typeface.NORMAL, 0, 0, 0, dp(10)));
        EditText inp = new EditText(this);
        inp.setText(getString(R.string.route_default_1)); inp.setTextColor(Color.parseColor("#E6EDF3"));
        inp.setHintTextColor(Color.parseColor("#484F58")); inp.setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 14); inp.setHint(R.string.route_name);
        inp.setSingleLine(true); inp.setFocusable(true); inp.setFocusableInTouchMode(true);
        inp.setBackground(makeInputBg()); inp.setPadding(dp(12), dp(10), dp(12), dp(10));
        inp.setSelectAllOnFocus(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) inp.setTextCursorDrawable(android.R.color.white);
        c.addView(inp);
        LinearLayout br = new LinearLayout(this); br.setOrientation(LinearLayout.HORIZONTAL); br.setGravity(Gravity.END); br.setPadding(0, dp(10), 0, 0);
        TextView bc = btn(getString(R.string.cancel), "#8B949E"); TextView bo = btn(getString(R.string.ok), "#00D4FF");
        br.addView(bc); br.addView(spacer(dp(20), 0)); br.addView(bo); c.addView(br);

        ScrollView sv = new ScrollView(this); sv.addView(c);
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DarkDialog); b.setView(sv);
        AlertDialog d = b.create(); d.setCancelable(false); d.show();

        bc.setOnClickListener(v -> { d.dismiss(); finish(); });
        bo.setOnClickListener(v -> {
            d.dismiss();
            Route r = new Route();
            String n = inp.getText().toString().trim(); r.name = n.isEmpty() ? getString(R.string.route_default_1) : n;
            r.timestamp = recT0; r.duration = System.currentTimeMillis() - recT0;
            r.totalDist = recDist; r.totalAsc = recAsc; r.altOff = 0; r.origAltOff = 0; r.baseAlt = baseAltitude;
            r.gpsEnabled = gpsEnabled; r.startLat = lat; r.startLon = lon;
            r.recordPrecision = precisionM == 0.1f ? 0 : precisionM == 0.5f ? 1 : 2; r.pts = pts;
            new DbHelper(this).insert(r); finish();
        });
    }

    // === Compass ===

    private void startCompassLoop() {
        compassUpdater = new Runnable() {
            @Override public void run() {
                compassView.update(heading, pitch, heading, recDist, state == State.RECORDING ? System.currentTimeMillis() - recT0 : 0, altitude);
                compassView.setGravity(gravX, gravY, gravZ, pitch, roll);
                if (calibrationView.getVisibility() == View.VISIBLE && calibrationView.isCalibrating()) calibrationView.updateSensor(pitch, roll);
                handler.postDelayed(this, 50);
            }
        };
        handler.post(compassUpdater);
    }

    @Override public void onBackPressed() { if (state == State.RECORDING) doPause(); else if (state == State.PAUSED || state == State.SAVE_SHOWN) doCancel(); else super.onBackPressed(); }

    @Override protected void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        if (bound) unbindService(conn);
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private String fmtDist(float m) { if (m >= 10000) return String.format(Locale.US, "%.1fkm", m/1000); if (m >= 1000) return String.format(Locale.US, "%.2fkm", m/1000); return String.format(Locale.US, "%.1fm", m); }
    private String fmtDur(long ms) { long s=ms/1000,h=s/3600,m=(s%3600)/60,sc=s%60; return h>0?String.format("%d:%02d:%02d",h,m,sc):String.format("%d:%02d",m,sc); }
}
