package com.traj.app;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;

public class SensorFusionManager implements SensorEventListener {
    public interface FusionCallback {
        void onOrientationUpdate(float heading, float pitch, float roll);
        void onGravityUpdate(float gx, float gy, float gz);
        void onAccuracyChanged(int accuracy);
    }

    private final SensorManager sm;
    private Sensor gameRV, accel, gyro, mag;
    private FusionCallback callback;
    private TrajectoryTracker tracker;

    private boolean useGameRV = false;
    private float[] rvMatrix = new float[9];
    private float[] rvOrient = new float[3];

    private float[] gravity = new float[3];
    private boolean gravityReady = false;
    private float[] geomag = new float[3];
    private float[] gyroAngle = {0, 0, 0};
    private long lastGyroTime = 0;
    private boolean gyroInitialized = false;
    private boolean hasMag = false;

    private float smoothHeading = 0, smoothPitch = 0, smoothRoll = 0;
    private boolean orientationInit = false;
    private static final float BASE_ALPHA = 0.2f;
    private static final float ADAPTIVE_FACTOR = 0.5f;

    private float displayHeading = 0, targetHeading = 0;
    private long lastUpdateTime = 0;
    private static final float INTERP_SPEED = 12f;

    private static final float GRAVITY = 9.80665f;

    private float gravX, gravY, gravZ;
    private float rawAccelX, rawAccelY, rawAccelZ;

    public SensorFusionManager(Context ctx) {
        sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gameRV = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
        if (gameRV == null) {
            gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        }
        Sensor gravitySensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if (gravitySensor != null) {
            sm.registerListener(this, gravitySensor, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    public void start(FusionCallback cb) {
        this.callback = cb;
        if (gameRV != null) {
            useGameRV = true;
            sm.registerListener(this, gameRV, SensorManager.SENSOR_DELAY_GAME);
        } else {
            if (gyro != null) sm.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
            if (mag != null) sm.registerListener(this, mag, SensorManager.SENSOR_DELAY_UI);
        }
        if (accel != null) sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME);
        lastUpdateTime = SystemClock.elapsedRealtime();
    }

    public void stop() { sm.unregisterListener(this); }
    public void setTracker(TrajectoryTracker t) { this.tracker = t; }

    public float[] getGravitySnapshot() { return new float[]{gravity[0], gravity[1], gravity[2]}; }
    public boolean isGravityReady() { return gravityReady; }

    public void reset() {
        gyroInitialized = false; gyroAngle = new float[]{0, 0, 0};
        orientationInit = false;
        // gravity NOT reset — physical state
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        switch (e.sensor.getType()) {
            case Sensor.TYPE_GAME_ROTATION_VECTOR: handleGameRV(e); break;
            case Sensor.TYPE_ACCELEROMETER: handleAccel(e); break;
            case Sensor.TYPE_GYROSCOPE: handleGyro(e); break;
            case Sensor.TYPE_MAGNETIC_FIELD: handleMag(e); break;
            case Sensor.TYPE_GRAVITY: handleGravitySensor(e); break;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor s, int a) {
        if (callback != null) callback.onAccuracyChanged(a);
    }

    private void handleGameRV(SensorEvent e) {
        SensorManager.getRotationMatrixFromVector(rvMatrix, e.values);
        SensorManager.getOrientation(rvMatrix, rvOrient);
        smoothOrientation(rvOrient[0], rvOrient[1], rvOrient[2]);
        if (tracker != null) tracker.feedRotation(rvMatrix);
    }

    private void handleAccel(SensorEvent e) {
        rawAccelX = e.values[0]; rawAccelY = e.values[1]; rawAccelZ = e.values[2];

        float alpha = 0.8f;
        gravity[0] = alpha * gravity[0] + (1 - alpha) * e.values[0];
        gravity[1] = alpha * gravity[1] + (1 - alpha) * e.values[1];
        gravity[2] = alpha * gravity[2] + (1 - alpha) * e.values[2];
        gravityReady = true;

        gravX = gravity[0] / GRAVITY;
        gravY = gravity[1] / GRAVITY;
        gravZ = gravity[2] / GRAVITY;

        if (tracker != null) {
            tracker.feedGravity(gravity[0], gravity[1], gravity[2]);
            tracker.feedAccel(rawAccelX, rawAccelY, rawAccelZ, e.timestamp);
        }

        if (!useGameRV) updateOrientationFallback();
        if (callback != null) callback.onGravityUpdate(gravX, gravY, gravZ);
    }

    private void handleGyro(SensorEvent e) {
        if (useGameRV) return;
        if (!gyroInitialized) { gyroInitialized = true; lastGyroTime = e.timestamp; return; }
        float dt = (e.timestamp - lastGyroTime) / 1e9f;
        lastGyroTime = e.timestamp;
        if (dt <= 0 || dt > 0.5f) return;
        gyroAngle[0] += e.values[0] * dt;
        gyroAngle[1] += e.values[1] * dt;
        gyroAngle[2] += e.values[2] * dt;
        updateOrientationFallback();
    }

    private void handleMag(SensorEvent e) {
        if (useGameRV) return;
        geomag[0] = e.values[0]; geomag[1] = e.values[1]; geomag[2] = e.values[2];
        hasMag = true;
        updateOrientationFallback();
    }

    private void handleGravitySensor(SensorEvent e) {
        gravity[0] = e.values[0]; gravity[1] = e.values[1]; gravity[2] = e.values[2];
        gravityReady = true;
        gravX = e.values[0] / GRAVITY; gravY = e.values[1] / GRAVITY; gravZ = e.values[2] / GRAVITY;
        if (callback != null) callback.onGravityUpdate(gravX, gravY, gravZ);
    }

    private void updateOrientationFallback() {
        float newHeading;
        if (hasMag && accel != null) {
            float[] R = new float[9], I = new float[9];
            if (SensorManager.getRotationMatrix(R, I, gravity, geomag)) {
                float[] o = new float[3]; SensorManager.getOrientation(R, o);
                newHeading = o[0];
            } else newHeading = gyroAngle[2];
        } else newHeading = gyroAngle[2];

        float newPitch = (float) Math.atan2(gravity[2], Math.sqrt(gravity[0] * gravity[0] + gravity[1] * gravity[1]));
        float newRoll = (float) Math.atan2(-gravity[0], gravity[2]);
        smoothOrientation(newHeading, newPitch, newRoll);
    }

    private void smoothOrientation(float newHeading, float newPitch, float newRoll) {
        if (!orientationInit) {
            smoothHeading = newHeading; smoothPitch = newPitch; smoothRoll = newRoll;
            targetHeading = newHeading; displayHeading = newHeading;
            orientationInit = true;
        } else {
            float headingDiff = newHeading - smoothHeading;
            while (headingDiff > Math.PI) headingDiff -= 2 * Math.PI;
            while (headingDiff < -Math.PI) headingDiff += 2 * Math.PI;
            float alpha = BASE_ALPHA + ADAPTIVE_FACTOR * Math.min(Math.abs(headingDiff) / (float) Math.PI, 1.0f);
            alpha = Math.min(alpha, 0.8f);
            smoothHeading += alpha * headingDiff;
            while (smoothHeading > Math.PI) smoothHeading -= 2 * Math.PI;
            while (smoothHeading < -Math.PI) smoothHeading += 2 * Math.PI;
            smoothPitch = 0.3f * smoothPitch + 0.7f * newPitch;
            smoothRoll = 0.3f * smoothRoll + 0.7f * newRoll;
        }
        targetHeading = smoothHeading;
        long now = SystemClock.elapsedRealtime();
        float dt = (now - lastUpdateTime) / 1000f;
        lastUpdateTime = now;
        if (dt > 0 && dt < 0.2f) {
            float diff = targetHeading - displayHeading;
            while (diff > Math.PI) diff -= 2 * Math.PI;
            while (diff < -Math.PI) diff += 2 * Math.PI;
            float maxStep = INTERP_SPEED * dt;
            if (Math.abs(diff) < maxStep) displayHeading = targetHeading;
            else displayHeading += Math.signum(diff) * maxStep;
            while (displayHeading > Math.PI) displayHeading -= 2 * Math.PI;
            while (displayHeading < -Math.PI) displayHeading += 2 * Math.PI;
        }
        if (callback != null) callback.onOrientationUpdate(displayHeading, smoothPitch, smoothRoll);
        if (!useGameRV && tracker != null) tracker.feedHeading(displayHeading);
    }

    public float getGravX() { return gravX; }
    public float getGravY() { return gravY; }
    public float getGravZ() { return gravZ; }
    public float getRawAccelX() { return rawAccelX; }
    public float getRawAccelY() { return rawAccelY; }
    public float getRawAccelZ() { return rawAccelZ; }
    public boolean isGameRVAvailable() { return gameRV != null; }
}
