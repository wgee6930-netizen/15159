package com.traj.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

public class CompassView extends View {
    private final Paint pRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pTick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pLabel = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pNeedle = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pNeedleTail = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pCenter = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pBubble = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pBubbleRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pBubbleBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path needlePath = new Path();
    private final Path tailPath = new Path();

    private float heading = 0, pitch = 0, roll = 0;
    private float moveBearing = 0;
    private float dist = 0, elapsed = 0, altitude = 0;

    // Bubble level via gravity vector
    private float gravX = 0, gravY = 0, gravZ = 1;

    public CompassView(Context ctx) { this(ctx, null); }
    public CompassView(Context ctx, AttributeSet a) { this(ctx, a, 0); }
    public CompassView(Context ctx, AttributeSet a, int d) {
        super(ctx, a, d);
        pRing.setColor(Color.parseColor("#00D4FF"));
        pRing.setStyle(Paint.Style.STROKE);
        pRing.setStrokeWidth(3);
        pTick.setStyle(Paint.Style.STROKE);
        pLabel.setColor(Color.parseColor("#E6EDF3"));
        pLabel.setTextAlign(Paint.Align.CENTER);
        pNeedle.setColor(Color.parseColor("#00D4FF"));
        pNeedleTail.setColor(Color.parseColor("#006688"));
        pCenter.setColor(Color.parseColor("#E6EDF3"));
        pText.setTextAlign(Paint.Align.CENTER);
        pBubbleRing.setStyle(Paint.Style.STROKE);
        pBubbleRing.setStrokeWidth(2);
        pBubbleBg.setStyle(Paint.Style.FILL);
    }

    public void update(float heading, float pitch, float moveBearing,
                       float dist, float elapsed, float altitude) {
        this.heading = heading;
        this.pitch = pitch;
        this.moveBearing = moveBearing;
        this.dist = dist;
        this.elapsed = elapsed;
        this.altitude = altitude;
        invalidate();
    }

    public void setGravity(float gx, float gy, float gz, float pitch, float roll) {
        // Raw accelerometer gravity vector (low-pass filtered):
        // gx > 0 → device tilted RIGHT → bubble moves LEFT
        // gy > 0 → device tilted FORWARD (top up) → bubble moves DOWN
        // Use negated values: bubble follows net force direction
        this.gravX = gx;
        this.gravY = gy;
        this.gravZ = gz;
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float cx = w / 2, cy = h / 2;
        float r = Math.min(cx, cy) * 0.85f;

        c.drawColor(Color.parseColor("#0d0d12"));

        // Draw bubble level FIRST (behind compass), fills the compass circle area
        drawBubbleLevel(c, cx, cy, r);

        // Compass ring - rotate so current heading is at top
        c.save();
        c.rotate((float) Math.toDegrees(-heading), cx, cy);

        // Outer ring
        c.drawCircle(cx, cy, r, pRing);

        // Ticks
        for (int a = 0; a < 360; a += 15) {
            float rad = (float) Math.toRadians(a);
            float r1 = a % 90 == 0 ? r * 0.9f : r * 0.96f;
            pTick.setColor(a % 90 == 0 ? Color.argb(128, 0, 212, 255) : Color.argb(50, 0, 212, 255));
            pTick.setStrokeWidth(a % 90 == 0 ? 3 : 1.5f);
            c.drawLine(
                cx + (float) Math.cos(rad) * r1, cy + (float) Math.sin(rad) * r1,
                cx + (float) Math.cos(rad) * r, cy + (float) Math.sin(rad) * r,
                pTick);
        }

        // N E S W
        String[] dirs = {"N", "E", "S", "W"};
        pLabel.setTextSize(r * 0.14f);
        for (int i = 0; i < 4; i++) {
            float rad = (float) Math.toRadians(i * 90);
            c.drawText(dirs[i],
                cx + (float) Math.cos(rad) * r * 0.78f,
                cy + (float) Math.sin(rad) * r * 0.78f + pLabel.getTextSize() * 0.35f,
                pLabel);
        }
        c.restore();

        // Needle
        float moveRel = moveBearing - heading;
        c.save();
        c.translate(cx, cy);
        c.rotate((float) Math.toDegrees(moveRel));
        float pitchFactor = (float) Math.cos(Math.max(-1, Math.min(1, pitch / (Math.PI / 3))));
        float scaleY = 0.3f + 0.7f * Math.abs(pitchFactor);
        c.scale(1, scaleY);

        float nLen = r * 0.42f;
        float nW = r * 0.1f;
        needlePath.reset();
        needlePath.moveTo(0, -nLen);
        needlePath.lineTo(-nW, -nLen * 0.35f);
        needlePath.lineTo(0, -nLen * 0.55f);
        needlePath.lineTo(nW, -nLen * 0.35f);
        needlePath.close();
        c.drawPath(needlePath, pNeedle);

        tailPath.reset();
        tailPath.moveTo(0, nLen);
        tailPath.lineTo(-nW * 0.8f, nLen * 0.5f);
        tailPath.lineTo(0, nLen * 0.65f);
        tailPath.lineTo(nW * 0.8f, nLen * 0.5f);
        tailPath.close();
        c.drawPath(tailPath, pNeedleTail);

        c.drawCircle(0, 0, r * 0.028f, pCenter);
        c.restore();

        // Top: heading
        float hd = (((float) Math.toDegrees(heading)) % 360 + 360) % 360;
        pText.setColor(Color.parseColor("#00D4FF"));
        pText.setTextSize(r * 0.1f);
        pText.setTextAlign(Paint.Align.CENTER);
        c.drawText(String.format("%.0f\u00B0", hd), cx, cy - r - r * 0.12f, pText);

        // Bottom: time
        pText.setColor(Color.parseColor("#E6EDF3"));
        pText.setTextSize(r * 0.075f);
        c.drawText(fmtDur((long) elapsed), cx, cy + r + r * 0.15f, pText);


    }

    private void drawBubbleLevel(Canvas c, float cx, float cy, float maxR) {
        // Physics: bubble follows NET force direction (gravity + centrifugal)
        // Accelerometer measures reaction to gravity, so:
        // accelX > 0 → device tilted RIGHT → net force RIGHT → bubble RIGHT
        // accelY > 0 → device tilted FORWARD → net force FORWARD → bubble DOWN on screen
        // No negation: bubble follows the force direction directly

        float bubbleX = gravX * maxR * 0.85f;
        float bubbleY = gravY * maxR * 0.85f;

        // Clamp to circle
        float dist = (float) Math.sqrt(bubbleX * bubbleX + bubbleY * bubbleY);
        if (dist > maxR * 0.85f) {
            bubbleX *= maxR * 0.85f / dist;
            bubbleY *= maxR * 0.85f / dist;
        }

        // Color: green when centered, blue when offset
        float offset = Math.min(dist / (maxR * 0.3f), 1.0f);
        int bubbleColor;
        if (offset < 0.15f) {
            bubbleColor = Color.parseColor("#00FF88"); // green = level
        } else {
            int gc = (int) (255 - offset * 120);
            int bc = (int) (136 + offset * 119);
            bubbleColor = Color.rgb(0, Math.max(0, gc), Math.min(255, bc));
        }

        // Background circle (subtle)
        pBubbleBg.setColor(Color.argb(25, 0, 212, 255));
        c.drawCircle(cx, cy, maxR, pBubbleBg);

        // Center crosshair
        pBubbleRing.setColor(Color.argb(40, 0, 212, 255));
        c.drawCircle(cx, cy, maxR * 0.3f, pBubbleRing);
        c.drawLine(cx - maxR * 0.05f, cy, cx + maxR * 0.05f, cy, pBubbleRing);
        c.drawLine(cx, cy - maxR * 0.05f, cx, cy + maxR * 0.05f, pBubbleRing);

        // Outer ring
        pBubbleRing.setColor(Color.argb(50, 0, 212, 255));
        c.drawCircle(cx, cy, maxR, pBubbleRing);

        // Bubble
        float bubbleR = maxR * 0.12f;
        pBubble.setShader(new RadialGradient(
            cx + bubbleX, cy + bubbleY, bubbleR,
            new int[]{bubbleColor, Color.argb(80, Color.red(bubbleColor), Color.green(bubbleColor), Color.blue(bubbleColor))},
            new float[]{0.4f, 1.0f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx + bubbleX, cy + bubbleY, bubbleR, pBubble);
        pBubble.setShader(null);
    }

    private String fmtDist(float m) {
        if (m >= 10000) return String.format("%.1fkm", m / 1000);
        if (m >= 1000) return String.format("%.2fkm", m / 1000);
        return String.format("%.1fm", m);
    }

    private String fmtDur(long ms) {
        long s = ms / 1000, h = s / 3600, m = (s % 3600) / 60, sc = s % 60;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, sc);
        return String.format("%d:%02d", m, sc);
    }
}
