package com.traj.app;

/**
 * 3D tracker with segmented bias correction.
 *
 * Two correction modes:
 *   1. Still→Still: v=0 constraint, exact correction
 *   2. Continuous movement: segment every 10s, assume average accel cancels,
 *      estimate bias from velocity drift, correct each segment
 *
 * Stationary: output completely frozen.
 */
public class TrajectoryTracker {

    private final float[] R = new float[9];
    private boolean rInit = false;
    private static final float R_ALPHA = 0.15f;

    private float gravX = 0, gravY = 0, gravZ = 0;
    private boolean gravInit = false;
    private boolean gravCalibrated = false;
    private float headingRad = 0;

    // === Segment state (no buffer needed — only integrated values) ===
    private float segVelN = 0, segVelE = 0, segVelD = 0;
    private float segDispN = 0, segDispE = 0, segDispD = 0;
    private long lastTs = 0;
    private long segStartTs = 0;
    private int segSampleCount = 0;

    // Auto-segmentation
    private static final float SEG_DURATION_S = 10f;
    private static final int SEG_MAX_SAMPLES = 2000;  // force commit if exceeded

    // Stillness
    private static final float STILL_THRESH = 0.12f;      // linear accel threshold
    private static final float STILL_GRAV_MIN = 8.0f;     // total accel must be near G
    private static final float STILL_GRAV_MAX = 11.0f;    // to confirm device is resting
    private static final int STILL_MIN = 15;
    private int stillCount = 0;
    private boolean frozen = true;

    // Gravity sanity: calibrated magnitude must stay near G
    private static final float GRAV_MAG_MIN = 8.5f;
    private static final float GRAV_MAG_MAX = 11.0f;

    // Output (cumulative, corrected)
    private float outDispN = 0, outDispE = 0, outDispD = 0;

    private boolean recording = false;
    private static final float G = 9.80665f;
    private float baseAlt = 0;

    public void startRecording(float base) {
        this.baseAlt = base;
        recording = true;
        outDispN = outDispE = outDispD = 0;
        resetSegment();
        stillCount = 0; frozen = true;
    }

    public void stopRecording() {
        if (!frozen && segSampleCount > 0) {
            correctAndCommit();
        }
        recording = false;
    }

    private void resetSegment() {
        segVelN = segVelE = segVelD = 0;
        segDispN = segDispE = segDispD = 0;
        segSampleCount = 0;
        segStartTs = 0;
        // Don't reset lastTs — keep real dt continuity
    }

    public void feedRotation(float[] m) {
        if (m == null || m.length < 9) return;
        if (!rInit) {
            System.arraycopy(m, 0, R, 0, 9);
            rInit = true;
        } else {
            for (int i = 0; i < 9; i++) R[i] += R_ALPHA * (m[i] - R[i]);
        }
        reorthogonalize();
    }

    private void reorthogonalize() {
        float l2 = len(R[6], R[7], R[8]);
        if (l2 > 0.01f) { R[6] /= l2; R[7] /= l2; R[8] /= l2; }
        float r1x = R[7]*R[2] - R[8]*R[1];
        float r1y = R[8]*R[0] - R[6]*R[2];
        float r1z = R[6]*R[1] - R[7]*R[0];
        float l1 = len(r1x, r1y, r1z);
        if (l1 > 0.01f) { R[3] = r1x/l1; R[4] = r1y/l1; R[5] = r1z/l1; }
        R[0] = R[4]*R[8] - R[5]*R[7];
        R[1] = R[5]*R[6] - R[3]*R[8];
        R[2] = R[3]*R[7] - R[4]*R[6];
    }

    public void feedHeading(float hRad) {
        this.headingRad = hRad;
        if (!rInit) {
            float c = (float) Math.cos(hRad), s = (float) Math.sin(hRad);
            R[0]=c; R[1]=-s; R[2]=0;
            R[3]=s; R[4]=c; R[5]=0;
            R[6]=0; R[7]=0; R[8]=1;
            rInit = true;
        }
    }

    public void feedGravity(float gx, float gy, float gz) {
        if (!gravCalibrated) {
            this.gravX = gx; this.gravY = gy; this.gravZ = gz;
        }
        this.gravInit = true;
    }

    public void feedAccel(float ax, float ay, float az, long ts) {
        if (!recording || !gravInit) return;

        float lx = ax - gravX;
        float ly = ay - gravY;
        float lz = az - gravZ;
        float linMag = len(lx, ly, lz);
        float totalMag = len(ax, ay, az);

        // === Stillness detection ===
        // Two conditions:
        //   1. Linear accel near zero (no acceleration relative to gravity)
        //   2. Total accel near G (device is resting, not in freefall)
        boolean linearStill = linMag < STILL_THRESH;
        boolean gravPresent = totalMag > STILL_GRAV_MIN && totalMag < STILL_GRAV_MAX;
        if (linearStill && gravPresent) {
            stillCount++;
            if (stillCount >= STILL_MIN) {
                // Still — adapt gravity toward current reading
                // But only if the new gravity magnitude is sane (near G)
                float newGravMag = len(ax, ay, az);
                if (newGravMag > GRAV_MAG_MIN && newGravMag < GRAV_MAG_MAX) {
                    float adaptAlpha = 0.1f;
                    gravX += adaptAlpha * (ax - gravX);
                    gravY += adaptAlpha * (ay - gravY);
                    gravZ += adaptAlpha * (az - gravZ);
                    gravCalibrated = true;
                }

                // Commit any in-progress segment
                if (!frozen && segSampleCount > 0) {
                    correctAndCommit();
                }
                frozen = true;
                stillCount = STILL_MIN;
            }
            return;
        }

        // === Moving ===
        if (frozen) {
            // Transition: still → moving
            frozen = false;
            resetSegment();
            segStartTs = ts;
            // lastTs preserved from before freeze for dt continuity
        }
        stillCount = 0;

        // Compute dt
        float dt;
        if (lastTs > 0) {
            dt = (ts - lastTs) / 1e9f;
            if (dt <= 0 || dt > 0.1f) dt = 0.02f;
        } else {
            dt = 0.02f;
        }
        lastTs = ts;

        // To world frame
        float uN, uE, uD;
        if (rInit) {
            uN = R[0]*lx + R[1]*ly + R[2]*lz;
            uE = R[3]*lx + R[4]*ly + R[5]*lz;
            uD = R[6]*lx + R[7]*ly + R[8]*lz;
        } else {
            float cH = (float) Math.cos(headingRad);
            float sH = (float) Math.sin(headingRad);
            uN = lx*cH - ly*sH;
            uE = lx*sH + ly*cH;
            uD = lz;
        }

        // Integrate
        segVelN += uN * dt;
        segVelE += uE * dt;
        segVelD += uD * dt;
        segDispN += segVelN * dt;
        segDispE += segVelE * dt;
        segDispD += segVelD * dt;
        segSampleCount++;

        // Force commit if buffer overflow
        if (segSampleCount >= SEG_MAX_SAMPLES) {
            correctAndCommit();
            resetSegment();
            segStartTs = ts;
            // Don't reset lastTs — keep dt continuity
            return;
        }

        // Auto-commit every SEG_DURATION_S
        if (segStartTs > 0) {
            float elapsed = (ts - segStartTs) / 1e9f;
            if (elapsed >= SEG_DURATION_S) {
                correctAndCommit();
                resetSegment();
                segStartTs = ts;
                // Don't reset lastTs — keep dt continuity
            }
        }
    }

    /**
     * Correct segment using bias estimation.
     * bias = v_end / T (assumed constant over segment)
     * corrected_disp = raw_disp - bias * T² / 2
     */
    private void correctAndCommit() {
        if (segSampleCount < 2) { resetSegment(); return; }

        float T;
        if (segStartTs > 0 && lastTs > segStartTs) {
            T = (lastTs - segStartTs) / 1e9f;
        } else {
            T = segSampleCount * 0.02f;
        }
        if (T <= 0) T = segSampleCount * 0.02f;

        // Bias estimate
        float bN = segVelN / T;
        float bE = segVelE / T;
        float bD = segVelD / T;

        // Corrected displacement
        float halfT2 = T * T / 2;
        outDispN += segDispN - bN * halfT2;
        outDispE += segDispE - bE * halfT2;
        outDispD += segDispD - bD * halfT2;

        resetSegment();
    }

    // === Queries ===

    public float horizDist() { return len(outDispN, outDispE, 0); }
    public float vertDisp() { return -outDispD; }
    public float altitude() { return baseAlt + vertDisp(); }

    /** Speed: frozen=0, moving=average speed over current segment */
    public float speed() {
        if (frozen || segSampleCount == 0) return 0;
        if (segStartTs <= 0 || lastTs <= segStartTs) return 0;
        float T = (lastTs - segStartTs) / 1e9f;
        if (T <= 0) return 0;
        float segDist = len(segDispN, segDispE, segDispD);
        return segDist / T;  // average speed, not instantaneous (less noisy)
    }

    public float hSpeed() {
        if (frozen || segSampleCount == 0) return 0;
        if (segStartTs <= 0 || lastTs <= segStartTs) return 0;
        float T = (lastTs - segStartTs) / 1e9f;
        if (T <= 0) return 0;
        float segHDist = len(segDispN, segDispE, 0);
        return segHDist / T;
    }

    public float headingDeg() {
        float h = rInit ? (float) Math.atan2(R[1], R[0]) : headingRad;
        return ((float) Math.toDegrees(h) + 360) % 360;
    }
    public float headingRad() { return rInit ? (float) Math.atan2(R[1], R[0]) : headingRad; }
    public float pitch() { return rInit ? (float) Math.asin(clamp(-R[8], -1, 1)) : 0; }
    public float roll() { return rInit ? (float) Math.atan2(R[5], R[8]) : 0; }
    public float gravNx() { return gravX / G; }
    public float gravNy() { return gravY / G; }
    public float gravNz() { return gravZ / G; }
    public void setBaseAlt(float a) { this.baseAlt = a; }
    public boolean hasData() { return gravInit; }

    private static float len(float x, float y, float z) {
        return (float) Math.sqrt(x*x + y*y + z*z);
    }
    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
