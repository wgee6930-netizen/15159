package com.traj.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * Xiaomi-style compass calibration: rotate device in a circle pattern.
 * Shows a target circle path, a live dot tracking device orientation,
 * and a progress arc that fills as the user completes the rotation.
 */
public class CalibrationView extends View {
    private final Paint pBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pTargetRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pProgressArc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pDot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pDotGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pTrail = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pHint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pCheckMark = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pInnerRing = new Paint(Paint.ANTI_ALIAS_FLAG);

    private boolean calibrating = false;
    private float sensorPitch = 0, sensorRoll = 0;

    // Trail of recent positions on the circle
    private static final int TRAIL_SIZE = 80;
    private float[] trailX = new float[TRAIL_SIZE];
    private float[] trailY = new float[TRAIL_SIZE];
    private int trailIdx = 0;
    private int trailCount = 0;

    // Progress: track how much of the circle has been covered
    // We divide the circle into segments and mark each one when visited
    private static final int SEGMENTS = 36;
    private boolean[] segmentsCovered = new boolean[SEGMENTS];
    private float progress = 0; // 0-1
    private boolean completed = false;
    private long completeTime = 0;

    // Angle smoothing
    private float smoothAngle = 0;
    private boolean angleInit = false;

    public CalibrationView(Context ctx) { this(ctx, null); }
    public CalibrationView(Context ctx, AttributeSet a) { this(ctx, a, 0); }
    public CalibrationView(Context ctx, AttributeSet a, int d) {
        super(ctx, a, d);

        pTargetRing.setStyle(Paint.Style.STROKE);
        pTargetRing.setStrokeWidth(3);
        pTargetRing.setColor(Color.argb(80, 0, 212, 255));

        pProgressArc.setStyle(Paint.Style.STROKE);
        pProgressArc.setStrokeWidth(5);
        pProgressArc.setStrokeCap(Paint.Cap.ROUND);

        pDot.setStyle(Paint.Style.FILL);
        pDotGlow.setStyle(Paint.Style.FILL);

        pTrail.setStyle(Paint.Style.FILL);

        pText.setColor(Color.parseColor("#E6EDF3"));
        pText.setTextAlign(Paint.Align.CENTER);

        pHint.setColor(Color.argb(160, 139, 148, 158));
        pHint.setTextAlign(Paint.Align.CENTER);

        pCheckMark.setStyle(Paint.Style.STROKE);
        pCheckMark.setStrokeWidth(4);
        pCheckMark.setStrokeCap(Paint.Cap.ROUND);
        pCheckMark.setStrokeJoin(Paint.Join.ROUND);
        pCheckMark.setColor(Color.parseColor("#00FF88"));

        pInnerRing.setStyle(Paint.Style.STROKE);
        pInnerRing.setStrokeWidth(1.5f);
        pInnerRing.setColor(Color.argb(40, 0, 212, 255));
    }

    public void startCalibration() {
        calibrating = true;
        completed = false;
        progress = 0;
        trailCount = 0;
        trailIdx = 0;
        angleInit = false;
        for (int i = 0; i < SEGMENTS; i++) segmentsCovered[i] = false;
        invalidate();
    }

    public void stopCalibration() {
        calibrating = false;
    }

    public boolean isCalibrating() { return calibrating; }
    public float getProgress() { return progress; }
    public boolean isCompleted() { return completed; }

    public void updateSensor(float pitch, float roll) {
        if (!calibrating) return;
        this.sensorPitch = pitch;
        this.sensorRoll = roll;

        float w = getWidth(), h = getHeight();
        float cx = w / 2, cy = h / 2;
        float ringR = Math.min(cx, cy) * 0.55f;

        // Map pitch/roll to angle on the circle
        // Device orientation → position on ring
        // roll → horizontal, pitch → vertical
        float angle = (float) Math.atan2(Math.sin(pitch), Math.sin(roll));

        // Smooth angle
        if (!angleInit) {
            smoothAngle = angle;
            angleInit = true;
        } else {
            float diff = angle - smoothAngle;
            while (diff > Math.PI) diff -= 2 * Math.PI;
            while (diff < -Math.PI) diff += 2 * Math.PI;
            smoothAngle += 0.25f * diff;
            while (smoothAngle > Math.PI) smoothAngle -= 2 * Math.PI;
            while (smoothAngle < -Math.PI) smoothAngle += 2 * Math.PI;
        }

        // Position on ring
        float sx = cx + (float) Math.cos(smoothAngle) * ringR;
        float sy = cy - (float) Math.sin(smoothAngle) * ringR;

        // Add to trail
        trailX[trailIdx] = sx;
        trailY[trailIdx] = sy;
        trailIdx = (trailIdx + 1) % TRAIL_SIZE;
        if (trailCount < TRAIL_SIZE) trailCount++;

        // Mark segment
        float normalizedAngle = (float) ((smoothAngle + 2 * Math.PI) % (2 * Math.PI));
        int seg = (int) (normalizedAngle / (2 * Math.PI) * SEGMENTS) % SEGMENTS;
        segmentsCovered[seg] = true;

        // Update progress
        int covered = 0;
        for (boolean s : segmentsCovered) if (s) covered++;
        progress = (float) covered / SEGMENTS;

        if (progress >= 1.0f && !completed) {
            completed = true;
            completeTime = System.currentTimeMillis();
        }

        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (!calibrating) return;

        float w = getWidth(), h = getHeight();
        float cx = w / 2, cy = h / 2;
        float ringR = Math.min(cx, cy) * 0.55f;

        // Dim background
        c.drawColor(Color.argb(220, 13, 17, 23));

        // Inner concentric rings (guide)
        pInnerRing.setColor(Color.argb(30, 0, 212, 255));
        c.drawCircle(cx, cy, ringR * 0.5f, pInnerRing);
        c.drawCircle(cx, cy, ringR * 0.75f, pInnerRing);

        // Crosshair
        pInnerRing.setColor(Color.argb(20, 0, 212, 255));
        c.drawLine(cx - ringR * 1.1f, cy, cx + ringR * 1.1f, cy, pInnerRing);
        c.drawLine(cx, cy - ringR * 1.1f, cx, cy + ringR * 1.1f, pInnerRing);

        // Target ring (dashed circle)
        RectF ringRect = new RectF(cx - ringR, cy - ringR, cx + ringR, cy + ringR);
        pTargetRing.setColor(Color.argb(60, 0, 212, 255));
        c.drawOval(ringRect, pTargetRing);

        // Progress arc (filled portion)
        if (progress > 0) {
            pProgressArc.setColor(Color.parseColor("#00D4FF"));
            pProgressArc.setStyle(Paint.Style.STROKE);
            c.drawArc(ringRect, -90, 360 * progress, false, pProgressArc);
        }

        // Trail dots
        for (int i = 0; i < trailCount; i++) {
            int idx = (trailIdx - trailCount + i + TRAIL_SIZE) % TRAIL_SIZE;
            float alpha = (float) i / trailCount;
            pTrail.setColor(Color.argb((int) (alpha * 150), 0, 212, 255));
            c.drawCircle(trailX[idx], trailY[idx], 3 + alpha * 3, pTrail);
        }

        // Current position dot
        float angle = smoothAngle;
        float sx = cx + (float) Math.cos(angle) * ringR;
        float sy = cy - (float) Math.sin(angle) * ringR;

        int dotColor = completed ? Color.parseColor("#00FF88") : Color.parseColor("#00D4FF");
        pDotGlow.setColor(Color.argb(50, Color.red(dotColor), Color.green(dotColor), Color.blue(dotColor)));
        c.drawCircle(sx, sy, 16, pDotGlow);

        pDot.setColor(dotColor);
        c.drawCircle(sx, sy, 8, pDot);

        // Center text
        if (completed) {
            // Checkmark
            float checkSize = ringR * 0.15f;
            pCheckMark.setStrokeWidth(4);
            Path checkPath = new Path();
            checkPath.moveTo(cx - checkSize, cy);
            checkPath.lineTo(cx - checkSize * 0.3f, cy + checkSize * 0.7f);
            checkPath.lineTo(cx + checkSize, cy - checkSize * 0.5f);
            c.drawPath(checkPath, pCheckMark);

            pText.setTextSize(ringR * 0.1f);
            pText.setColor(Color.parseColor("#00FF88"));
            c.drawText(getString(R.string.calibration_done), cx, cy + ringR * 0.35f, pText);
        } else {
            // Progress percentage
            pText.setTextSize(ringR * 0.2f);
            pText.setColor(Color.parseColor("#E6EDF3"));
            c.drawText(String.format("%d%%", (int) (progress * 100)), cx, cy + ringR * 0.08f, pText);
        }

        // Hint text below ring
        pHint.setTextSize(ringR * 0.09f);
        if (!completed) {
            c.drawText("\u8F6C\u52A8\u8BBE\u5907\u753B\u5706", cx, cy + ringR + ringR * 0.25f, pHint);
            // "Rotate device in a circle"
        }

        // Auto-dismiss after completion
        if (completed && System.currentTimeMillis() - completeTime > 1500) {
            stopCalibration();
            setVisibility(View.GONE);
        }
    }

    private String getString(int resId) {
        return getContext().getString(resId);
    }
}
