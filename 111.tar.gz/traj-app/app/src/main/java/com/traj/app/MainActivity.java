package com.traj.app;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int PERM_REQUEST = 1001;
    private WebView webView;
    private LocationService locationService;
    private boolean serviceBound = false;
    private BroadcastReceiver locationReceiver;
    private boolean webViewReady = false;
    private boolean pendingStartRecording = false;

    private final List<String> pendingLocationData = new ArrayList<>();

    private final ServiceConnection serviceConn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            locationService = ((LocationService.LocalBinder) binder).getService();
            serviceBound = true;
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            locationService = null;
            serviceBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupSystemBars();

        webView = new WebView(this);
        setContentView(webView);
        setupWebView();
        registerLocationReceiver();

        Intent svcIntent = new Intent(this, LocationService.class);
        bindService(svcIntent, serviceConn, Context.BIND_AUTO_CREATE);
    }

    private void setupSystemBars() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window w = getWindow();
            w.setNavigationBarColor(Color.parseColor("#0d1117"));
            w.setStatusBarColor(Color.parseColor("#0d1117"));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    private void setupWebView() {
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setDatabasePath(getDir("databases", 0).getPath());
        ws.setAllowFileAccess(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setUseWideViewPort(true);
        ws.setLoadWithOverviewMode(true);
        ws.setGeolocationEnabled(true);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setTextZoom(100);

        webView.addJavascriptInterface(this, "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                webViewReady = true;
                flushPendingData();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin,
                    GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void registerLocationReceiver() {
        locationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (LocationService.ACTION_LOCATION.equals(intent.getAction())) {
                    sendLocationToWebView(intent);
                } else if (LocationService.ACTION_STATUS.equals(intent.getAction())) {
                    if (intent.hasExtra("error")) {
                        callJS("onNativeError", "\"" + escapeJS(intent.getStringExtra("error")) + "\"");
                    } else {
                        callJS("onNativeGpsStatus",
                            intent.getBooleanExtra("gpsFixed", false) + ","
                            + intent.getIntExtra("satellites", 0));
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(LocationService.ACTION_LOCATION);
        filter.addAction(LocationService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(locationReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(locationReceiver, filter);
        }
    }

    private void sendLocationToWebView(Intent intent) {
        String json = "{"
            + "\"lat\":" + intent.getFloatExtra("lat", 0) + ","
            + "\"lon\":" + intent.getFloatExtra("lon", 0) + ","
            + "\"alt\":" + intent.getFloatExtra("alt", 0) + ","
            + "\"speed\":" + intent.getFloatExtra("speed", 0) + ","
            + "\"bearing\":" + intent.getFloatExtra("bearing", 0) + ","
            + "\"accuracy\":" + intent.getFloatExtra("accuracy", 999) + ","
            + "\"satellites\":" + intent.getIntExtra("satellites", 0) + ","
            + "\"isNetwork\":" + intent.getBooleanExtra("isNetwork", false) + ","
            + "\"heading\":" + intent.getFloatExtra("heading", 0) + ","
            + "\"pitch\":" + intent.getFloatExtra("pitch", 0) + ","
            + "\"roll\":" + intent.getFloatExtra("roll", 0) + ","
            + "\"steps\":" + intent.getIntExtra("steps", 0) + ","
            + "\"sensorDist\":" + intent.getFloatExtra("sensorDist", 0) + ","
            + "\"pressure\":" + intent.getFloatExtra("pressure", 0) + ","
            + "\"pressureAlt\":" + intent.getFloatExtra("pressureAlt", 0) + ","
            + "\"totalDist\":" + intent.getFloatExtra("totalDist", 0) + ","
            + "\"totalAsc\":" + intent.getFloatExtra("totalAsc", 0) + ","
            + "\"totalDesc\":" + intent.getFloatExtra("totalDesc", 0) + ","
            + "\"elapsed\":" + intent.getLongExtra("elapsed", 0)
            + "}";
        if (webViewReady) {
            callJS("onNativeLocation", json);
        } else {
            synchronized (pendingLocationData) { pendingLocationData.add(json); }
        }
    }

    private void flushPendingData() {
        synchronized (pendingLocationData) {
            for (String json : pendingLocationData) callJS("onNativeLocation", json);
            pendingLocationData.clear();
        }
    }

    private void callJS(final String func, final String args) {
        runOnUiThread(() -> {
            if (webView != null && webViewReady)
                webView.evaluateJavascript(func + "(" + args + ")", null);
        });
    }

    // === JS Interface ===

    @JavascriptInterface
    public void startService() {
        runOnUiThread(this::checkPermissionAndStart);
    }

    @JavascriptInterface
    public void stopService() {
        if (serviceBound && locationService != null) locationService.stopRecording();
        runOnUiThread(() -> getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON));
    }

    @JavascriptInterface
    public boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED;
    }

    @JavascriptInterface
    public void openAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.fromParts("package", getPackageName(), null));
        startActivity(intent);
    }

    @JavascriptInterface
    public void onWebViewReady() {
        webViewReady = true;
        flushPendingData();
    }

    @JavascriptInterface
    public String getNativeInfo() {
        SensorFusionManager sf = serviceBound && locationService != null
            ? locationService.getSensorFusion() : null;
        return "{"
            + "\"hasBaro\":" + (sf != null && sf.isBaroAvailable()) + ","
            + "\"hasGyro\":" + (sf != null && sf.isGyroAvailable()) + ","
            + "\"hasStepCounter\":" + (sf != null && sf.isStepCounterAvailable()) + ","
            + "\"sdkVersion\":" + Build.VERSION.SDK_INT
            + "}";
    }

    @JavascriptInterface
    public void keepScreenOn(final boolean on) {
        runOnUiThread(() -> {
            if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
    }

    @JavascriptInterface
    public void markSetupDone() {
        getSharedPreferences("traj_prefs", MODE_PRIVATE)
            .edit().putBoolean("setup_done", true).apply();
    }

    @JavascriptInterface
    public void requestBackgroundPermissionNow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runOnUiThread(() -> {
                requestPermissions(
                    new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION},
                    PERM_REQUEST + 1);
            });
        }
    }

    // === 权限 ===

    private void checkPermissionAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            pendingStartRecording = true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERM_REQUEST);
            return;
        }
        doStartRecording();
    }

    private void doStartRecording() {
        pendingStartRecording = false;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Intent svcIntent = new Intent(this, LocationService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svcIntent);
        else startService(svcIntent);
        if (!serviceBound) bindService(svcIntent, serviceConn, Context.BIND_AUTO_CREATE);

        callJS("onRecordingStarted", "true");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERM_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                doStartRecording();
            } else {
                callJS("onNativeError", "\"需要定位权限才能录制轨迹\"");
                pendingStartRecording = false;
            }
        } else if (requestCode == PERM_REQUEST + 1) {
            boolean granted = grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            callJS("onBackgroundPermissionResult", granted ? "true" : "false");
        }
    }

    // === 生命周期 ===

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override
    public void onBackPressed() {
        runOnUiThread(() -> webView.evaluateJavascript("handleBack()", null));
    }

    @Override
    protected void onDestroy() {
        if (locationReceiver != null) unregisterReceiver(locationReceiver);
        if (serviceBound) unbindService(serviceConn);
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private String escapeJS(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }
}
