package com.traj.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * 原生GPS前台服务
 * - 持续GPS定位（1秒间隔）
 * - 传感器融合（步态/航向/气压）
 * - 低通滤波降噪
 * - 与WebView通过Broadcast通信
 */
public class LocationService extends Service implements LocationListener {

    public static final String ACTION_LOCATION = "com.traj.app.LOCATION_UPDATE";
    public static final String ACTION_STATUS = "com.traj.app.STATUS_UPDATE";
    public static final String CHANNEL_ID = "trajectory_recorder";
    private static final int NOTIFICATION_ID = 1;
    private static final float GPS_MIN_DISTANCE = 0.5f; // 米
    private static final long GPS_MIN_TIME = 1000; // 毫秒

    private PowerManager.WakeLock wakeLock;
    private LocationManager locationManager;
    private SensorFusionManager sensorFusion;
    private Handler mainHandler;
    private boolean recording = false;

    // 平滑状态
    private Location lastLocation = null;
    private float smoothedLat = 0, smoothedLon = 0, smoothedAlt = 0;
    private boolean hasSmoothed = false;
    private static final float SMOOTH_FACTOR = 0.3f; // 越小越平滑

    // 累计数据
    private float totalDistance = 0;
    private float totalAscend = 0;
    private float totalDescend = 0;
    private float lastAlt = Float.NaN;
    private long startTime = 0;

    // GPS状态
    private int satelliteCount = 0;
    private boolean gpsFixed = false;
    private int consecutiveFailures = 0;
    private GnssStatus.Callback gnssCallback = null;

    // 传感器融合回调
    private float sensorHeading = 0, sensorPitch = 0, sensorRoll = 0;
    private float sensorPressure = 0, sensorAltitude = 0;
    private int sensorSteps = 0;
    private float sensorDistance = 0;

    // Binder
    private final IBinder binder = new LocalBinder();

    public class LocalBinder extends Binder {
        LocationService getService() { return LocationService.this; }
    }

    @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public void onCreate() {
        super.onCreate();
        mainHandler = new Handler(Looper.getMainLooper());

        // WakeLock
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "traj:recording");
        wakeLock.acquire();

        // 位置管理器
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        // 传感器融合
        sensorFusion = new SensorFusionManager(this);
        sensorFusion.start(new SensorFusionManager.FusionCallback() {
            @Override
            public void onOrientationUpdate(float heading, float pitch, float roll) {
                sensorHeading = heading;
                sensorPitch = pitch;
                sensorRoll = roll;
            }

            @Override
            public void onStepUpdate(int steps, float distance, float stepLength) {
                sensorSteps = steps;
                sensorDistance = distance;
            }

            @Override
            public void onBarometerUpdate(float pressureHpa, float altitudeM) {
                sensorPressure = pressureHpa;
                sensorAltitude = altitudeM;
            }

            @Override
            public void onAccuracyChanged(int accuracy) {}
        });

        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification("正在记录轨迹…"));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!recording) {
            startRecording();
        }
        return START_STICKY;
    }

    public void startRecording() {
        if (recording) return;
        recording = true;
        startTime = System.currentTimeMillis();
        totalDistance = 0;
        totalAscend = 0;
        totalDescend = 0;
        lastAlt = Float.NaN;
        lastLocation = null;
        hasSmoothed = false;
        consecutiveFailures = 0;
        sensorFusion.reset();

        try {
            // GPS定位
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                GPS_MIN_TIME,
                GPS_MIN_DISTANCE,
                this,
                mainHandler.getLooper()
            );

            // 监听卫星状态
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                gnssCallback = new GnssStatus.Callback() {
                    @Override
                    public void onSatelliteStatusChanged(GnssStatus status) {
                        satelliteCount = 0;
                        for (int i = 0; i < status.getSatelliteCount(); i++) {
                            if (status.usedInFix(i)) satelliteCount++;
                        }
                    }
                    @Override
                    public void onFirstFix(int ttffMillis) {
                        gpsFixed = true;
                        broadcastStatus();
                    }
                };
                locationManager.registerGnssStatusCallback(gnssCallback, mainHandler);
            }

            // 网络定位作为备用
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    3000,
                    0,
                    new LocationListener() {
                        @Override
                        public void onLocationChanged(Location location) {
                            // 仅在GPS不可用时使用网络定位
                            if (!gpsFixed || consecutiveFailures >= 3) {
                                processLocation(location, true);
                            }
                        }
                        @Override
                        public void onStatusChanged(String s, int i, Bundle b) {}
                        @Override
                        public void onProviderEnabled(String s) {}
                        @Override
                        public void onProviderDisabled(String s) {}
                    },
                    mainHandler.getLooper()
                );
            }

        } catch (SecurityException e) {
            broadcastError("定位权限被拒绝");
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        processLocation(location, false);
        consecutiveFailures = 0;
        if (!gpsFixed) {
            gpsFixed = true;
            broadcastStatus();
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override
    public void onProviderEnabled(String provider) {}

    @Override
    public void onProviderDisabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) {
            broadcastError("GPS已关闭");
        }
    }

    private static final long STALE_THRESHOLD_MS = 10000; // 超过10秒的GPS数据视为过期
    private static final float GPS_DRIFT_MIN_DIST = 3.0f; // 位移<3米视为漂移
    private static final float GPS_DRIFT_MAX_ACC = 15.0f; // 精度>15米时更严格过滤

    private void processLocation(Location loc, boolean isNetwork) {
        // 跳过过期数据（后台排队的旧GPS点）
        long age = System.currentTimeMillis() - loc.getTime();
        if (age > STALE_THRESHOLD_MS) return;

        float accuracy = loc.hasAccuracy() ? loc.getAccuracy() : 999;
        float speed = loc.hasSpeed() ? loc.getSpeed() : 0;
        float bearing = loc.hasBearing() ? loc.getBearing() : sensorHeading;
        double lat = loc.getLatitude();
        double lon = loc.getLongitude();
        double alt = loc.hasAltitude() ? loc.getAltitude() : sensorAltitude;

        // 低通滤波平滑
        if (!hasSmoothed) {
            smoothedLat = (float) lat;
            smoothedLon = (float) lon;
            smoothedAlt = (float) alt;
            hasSmoothed = true;
        } else {
            float w = Math.max(0.1f, Math.min(0.8f, 1.0f - accuracy / 100f));
            smoothedLat = smoothedLat + w * ((float) lat - smoothedLat);
            smoothedLon = smoothedLon + w * ((float) lon - smoothedLon);
            smoothedAlt = smoothedAlt + w * ((float) alt - smoothedAlt);
        }

        // ★ 核心：传感器距离为主，GPS距离为辅
        float gpsDist = 0;
        if (lastLocation != null) {
            float[] results = new float[1];
            Location.distanceBetween(
                lastLocation.getLatitude(), lastLocation.getLongitude(),
                lat, lon, results);
            gpsDist = results[0];

            // 跳过不合理跳跃（>50m/s）
            float dt = (loc.getTime() - lastLocation.getTime()) / 1000f;
            if (dt > 0 && gpsDist / dt > 50) gpsDist = 0;

            // GPS漂移过滤：精度差或位移太小，GPS距离归零
            if (accuracy > GPS_DRIFT_MAX_ACC && gpsDist < GPS_DRIFT_MIN_DIST * 2) gpsDist = 0;
            else if (accuracy > 10 && gpsDist < GPS_DRIFT_MIN_DIST) gpsDist = 0;
        }

        // 取传感器距离和GPS距离的较大值（传感器不受漂移影响）
        float sensorDist = sensorDistance;
        float bestDist = Math.max(sensorDist, gpsDist);
        totalDistance = bestDist;

        // 海拔累计（用气压计高度，不依赖GPS）
        float curAlt = sensorAltitude != 0 ? sensorAltitude : (float) alt;
        if (!Float.isNaN(lastAlt)) {
            float da = curAlt - lastAlt;
            if (Math.abs(da) < 5 && Math.abs(da) > 0.1f) {
                totalAscend += da;
            }
        }
        lastAlt = curAlt;

        Location copy = new Location(loc);
        lastLocation = copy;

        // 广播给WebView
        broadcastLocation(smoothedLat, smoothedLon, smoothedAlt, speed,
            bearing, accuracy, satelliteCount, isNetwork);
    }

    private void broadcastLocation(float lat, float lon, float alt,
            float speed, float bearing, float accuracy, int sats, boolean isNetwork) {
        Intent intent = new Intent(ACTION_LOCATION);
        intent.putExtra("lat", lat);
        intent.putExtra("lon", lon);
        intent.putExtra("alt", alt);
        intent.putExtra("speed", speed);
        intent.putExtra("bearing", bearing);
        intent.putExtra("accuracy", accuracy);
        intent.putExtra("satellites", sats);
        intent.putExtra("isNetwork", isNetwork);
        intent.putExtra("heading", sensorHeading);
        intent.putExtra("pitch", sensorPitch);
        intent.putExtra("roll", sensorRoll);
        intent.putExtra("steps", sensorSteps);
        intent.putExtra("sensorDist", sensorDistance);
        intent.putExtra("pressure", sensorPressure);
        intent.putExtra("pressureAlt", sensorAltitude);
        intent.putExtra("totalDist", totalDistance);
        intent.putExtra("totalAsc", totalAscend);
        intent.putExtra("totalDesc", totalDescend);
        intent.putExtra("elapsed", System.currentTimeMillis() - startTime);
        sendBroadcast(intent);
    }

    private void broadcastStatus() {
        Intent intent = new Intent(ACTION_STATUS);
        intent.putExtra("gpsFixed", gpsFixed);
        intent.putExtra("satellites", satelliteCount);
        sendBroadcast(intent);
    }

    private void broadcastError(String msg) {
        Intent intent = new Intent(ACTION_STATUS);
        intent.putExtra("error", msg);
        sendBroadcast(intent);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "轨迹记录", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("GPS轨迹记录服务");
            ch.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(String text) {
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nb = new Notification.Builder(this, CHANNEL_ID);
        } else {
            nb = new Notification.Builder(this);
        }
        return nb
            .setContentTitle("轨迹记录器")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build();
    }

    public void updateNotification(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    public void stopRecording() {
        recording = false;
        locationManager.removeUpdates(this);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && gnssCallback != null) {
                locationManager.unregisterGnssStatusCallback(gnssCallback);
                gnssCallback = null;
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        stopRecording();
        sensorFusion.stop();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        stopForeground(true);
        super.onDestroy();
    }

    // === Getters ===
    public boolean isRecording() { return recording; }
    public float getTotalDistance() { return totalDistance; }
    public float getTotalAscend() { return totalAscend; }
    public float getTotalDescend() { return totalDescend; }
    public long getElapsedTime() { return startTime > 0 ? System.currentTimeMillis() - startTime : 0; }
    public int getSatelliteCount() { return satelliteCount; }
    public boolean isGpsFixed() { return gpsFixed; }
    public SensorFusionManager getSensorFusion() { return sensorFusion; }
}
