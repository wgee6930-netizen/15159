#!/bin/bash
set -e

ANDROID_HOME=${ANDROID_HOME:-$HOME/android-sdk}
JAVA_HOME=${JAVA_HOME:-$(ls -d $HOME/jdk-17* 2>/dev/null | head -1)}
export PATH=$JAVA_HOME/bin:$PATH
BT=$ANDROID_HOME/build-tools/34.0.0
PL=$ANDROID_HOME/platforms/android-34/android.jar
D=$(cd "$(dirname "$0")" && pwd)
S=$D/app/src/main
O=$D/build

# === 图标 ===
echo "=== 0. 处理图标 ==="
ICON_SRC=""
for f in $D/icon_map2_1024.png $D/0000/1/icon_map2_1024.png $D/icon.png; do
  [ -f "$f" ] && ICON_SRC="$f" && break
done
if [ -n "$ICON_SRC" ]; then
  echo "  源图标: $ICON_SRC"
  mkdir -p $S/res/mipmap-mdpi $S/res/mipmap-hdpi $S/res/mipmap-xhdpi $S/res/mipmap-xxhdpi $S/res/mipmap-xxxhdpi
  ffmpeg -y -i "$ICON_SRC" -s 48x48   $S/res/mipmap-mdpi/ic_launcher.png   2>/dev/null
  ffmpeg -y -i "$ICON_SRC" -s 72x72   $S/res/mipmap-hdpi/ic_launcher.png   2>/dev/null
  ffmpeg -y -i "$ICON_SRC" -s 96x96   $S/res/mipmap-xhdpi/ic_launcher.png  2>/dev/null
  ffmpeg -y -i "$ICON_SRC" -s 144x144 $S/res/mipmap-xxhdpi/ic_launcher.png 2>/dev/null
  ffmpeg -y -i "$ICON_SRC" -s 192x192 $S/res/mipmap-xxxhdpi/ic_launcher.png 2>/dev/null
  echo "  图标已生成"
else
  echo "  ⚠ 未找到图标文件，使用默认"
  # 创建占位图标
  mkdir -p $S/res/mipmap-mdpi $S/res/mipmap-hdpi $S/res/mipmap-xhdpi $S/res/mipmap-xxhdpi $S/res/mipmap-xxxhdpi
  for sz in "48:mdpi" "72:hdpi" "96:xhdpi" "144:xxhdpi" "192:xxxhdpi"; do
    SIZE=${sz%%:*};DIR=${sz##*:}
    if [ ! -f "$S/res/mipmap-$DIR/ic_launcher.png" ]; then
      # 用 ImageMagick 或 Python 生成纯色占位图
      python3 -c "
from PIL import Image
img = Image.new('RGBA', ($SIZE, $SIZE), (0, 212, 255, 255))
img.save('$S/res/mipmap-$DIR/ic_launcher.png')
" 2>/dev/null || echo "  ⚠ 无法生成占位图标 $DIR"
    fi
  done
fi

# === 版本同步 ===
echo "=== 版本同步 ==="
VER=$(grep -oP 'versionName="\K[^"]+' $S/AndroidManifest.xml)
echo "  版本: $VER"

# 编译
echo "=== 1. aapt2 compile ==="
rm -rf $O && mkdir -p $O/gen $O/obj $O/dex $O/apk
$BT/aapt2 compile --dir $S/res -o $O/resources.zip

echo "=== 2. aapt2 link ==="
$BT/aapt2 link -o $O/apk/app.unsigned.apk -I $PL \
  --manifest $S/AndroidManifest.xml --java $O/gen \
  -A $S/assets --auto-add-overlay $O/resources.zip

echo "=== 3. javac ==="
javac -encoding UTF-8 -classpath $PL -d $O/obj \
  $O/gen/com/traj/app/R.java \
  $S/java/com/traj/app/MainActivity.java \
  $S/java/com/traj/app/LocationService.java \
  $S/java/com/traj/app/SensorFusionManager.java

echo "=== 4. d8 ==="
$BT/d8 --output $O/dex --lib $PL $O/obj/com/traj/app/*.class

echo "=== 5. 打包 ==="
cd $O/apk
cp app.unsigned.apk app.tmp.apk
# 用Python添加dex（兼容无zip环境）
python3 -c "
import zipfile
with zipfile.ZipFile('app.tmp.apk','r') as zin:
    with zipfile.ZipFile('app.withdex.apk','w',zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            zout.writestr(item, zin.read(item.filename))
        zout.write('$O/dex/classes.dex','classes.dex')
"
mv app.withdex.apk app.tmp.apk

echo "=== 6. zipalign ==="
$BT/zipalign -f 4 app.tmp.apk app.aligned.apk

echo "=== 7. 签名 ==="
KS=$D/app/release.keystore
[ ! -f "$KS" ] && [ -f ~/release.keystore ] && cp ~/release.keystore $KS
if [ ! -f "$KS" ]; then
  # 从环境变量读取密码，不硬编码
  KS_PASS=${KEYSTORE_PASS:-"$(head -c 16 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | head -c 16)"}
  echo "  生成新 keystore，密码: $KS_PASS"
  echo "  ⚠ 请妥善保存密码！"
  keytool -genkey -v -keystore $KS -alias release \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass "$KS_PASS" -keypass "$KS_PASS" \
    -dname "CN=Traj,OU=Dev,O=Home,L=SH,ST=SH,C=CN"
  echo "$KS_PASS" > "$KS.pass"
  chmod 600 "$KS.pass"
fi

# 从密码文件或环境变量读取
if [ -f "$KS.pass" ]; then
  KS_PASS=$(cat "$KS.pass")
elif [ -n "$KEYSTORE_PASS" ]; then
  KS_PASS="$KEYSTORE_PASS"
else
  echo "  ⚠ 无法获取 keystore 密码，请设置 KEYSTORE_PASS 环境变量"
  exit 1
fi

$BT/apksigner sign --ks $KS --ks-pass "pass:$KS_PASS" \
  --key-pass "pass:$KS_PASS" --ks-key-alias release \
  --out $D/TrajectoryRecorder-v${VER}.apk app.aligned.apk

echo ""
echo "=== ✅ 完成 ==="
ls -lh $D/TrajectoryRecorder-v${VER}.apk
