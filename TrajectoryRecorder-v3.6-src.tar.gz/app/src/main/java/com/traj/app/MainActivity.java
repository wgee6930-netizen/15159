package com.traj.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private DbHelper db;
    private List<Route> routes = new ArrayList<>();
    private BaseAdapter adapter;
    private ListView listView;
    private View delBar;
    private TextView delCnt;
    private Set<Long> selectedIds = new HashSet<>();
    private boolean selectMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyLocale();
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#161B22"));
            getWindow().setStatusBarColor(Color.parseColor("#161B22"));
        }
        setContentView(R.layout.activity_main);

        db = new DbHelper(this);
        listView = findViewById(R.id.listView);
        delBar = findViewById(R.id.delBar);
        delCnt = findViewById(R.id.delCnt);

        TextView tvVersion = findViewById(R.id.tvVersion);
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            tvVersion.setText("v" + pInfo.versionName);
        } catch (PackageManager.NameNotFoundException e) { tvVersion.setText(""); }

        adapter = new BaseAdapter() {
            @Override public int getCount() { return routes.size(); }
            @Override public Object getItem(int i) { return routes.get(i); }
            @Override public long getItemId(int i) { return routes.get(i).id; }
            @Override
            public View getView(int i, View cv, ViewGroup parent) {
                if (cv == null) cv = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_route, parent, false);
                Route r = routes.get(i);
                TextView nm = cv.findViewById(R.id.itName);
                TextView dt = cv.findViewById(R.id.itDate);
                TextView st = cv.findViewById(R.id.itStats);
                nm.setText(r.name != null ? r.name : getString(R.string.route_name));
                SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault());
                dt.setText(df.format(new Date(r.timestamp)));
                st.setText(fmtDist(r.totalDist) + " | " + (r.totalAsc >= 0 ? "+" : "") + String.format(Locale.US, "%.1f", r.totalAsc) + "m");
                cv.setBackgroundColor(selectedIds.contains(r.id) ? 0xFF1A2A3A : 0xFF161B22);
                cv.setOnClickListener(v -> { if (selectMode) toggleSelect(r.id); else openView(r.id); });
                cv.setOnLongClickListener(v -> { if (!selectMode) { selectMode = true; selectedIds.clear(); } toggleSelect(r.id); return true; });
                return cv;
            }
        };
        listView.setAdapter(adapter);

        findViewById(R.id.btnStart).setOnClickListener(v -> startActivity(new Intent(this, RecordActivity.class)));
        findViewById(R.id.delCancel).setOnClickListener(v -> exitSelectMode());
        findViewById(R.id.delBtn).setOnClickListener(v -> { for (Long id : selectedIds) db.delete(id); exitSelectMode(); loadRoutes(); });
        findViewById(R.id.btnGear).setOnClickListener(v -> showLanguagePicker());
    }

    /**
     * Apply locale without shrinking fonts.
     *
     * ROOT CAUSE: Resources.updateConfiguration() modifies the DisplayMetrics
     * object IN PLACE. After the call, dm.density / dm.scaledDensity may change.
     * On the NEXT call (e.g. after recreate), getDisplayMetrics() returns the
     * already-modified values, so density compounds and fonts shrink each time.
     *
     * FIX: Save original density/scaledDensity BEFORE calling updateConfiguration,
     * then restore them AFTER. This ensures the metrics never drift.
     */
    private void applyLocale() {
        SharedPreferences prefs = getSharedPreferences("traj", MODE_PRIVATE);
        String lang = prefs.getString("lang", "");
        if (lang.isEmpty()) return;

        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Resources res = getResources();
        Configuration cfg = res.getConfiguration();
        DisplayMetrics dm = res.getDisplayMetrics();

        // Save original density values BEFORE updateConfiguration changes them
        float origDensity = dm.density;
        float origDensityDpi = dm.densityDpi;
        float origScaledDensity = dm.scaledDensity;

        cfg.setLocale(locale);
        res.updateConfiguration(cfg, dm);

        // Restore density (updateConfiguration may modify it)
        dm.density = origDensity;
        dm.densityDpi = (int) origDensityDpi;
        dm.scaledDensity = origScaledDensity;
    }

    @Override protected void onResume() { super.onResume(); loadRoutes(); }
    private void loadRoutes() { routes = db.getAll(); adapter.notifyDataSetChanged(); }

    private void openView(long id) {
        Intent i = new Intent(this, ViewActivity.class); i.putExtra("routeId", id); startActivity(i);
    }

    private void toggleSelect(long id) {
        if (selectedIds.contains(id)) selectedIds.remove(id); else selectedIds.add(id);
        if (selectedIds.isEmpty()) exitSelectMode();
        else { delBar.setVisibility(View.VISIBLE); delCnt.setText(getString(R.string.selected_count, selectedIds.size())); }
        adapter.notifyDataSetChanged();
    }

    private void exitSelectMode() { selectMode = false; selectedIds.clear(); delBar.setVisibility(View.GONE); adapter.notifyDataSetChanged(); }

    private void showLanguagePicker() {
        String[] langs = { getString(R.string.follow_system), "\u4E2D\u6587", "English", "Deutsch" };
        new AlertDialog.Builder(this)
            .setTitle(R.string.language)
            .setItems(langs, (d, w) -> {
                String lang = w == 0 ? "" : w == 1 ? "zh" : w == 2 ? "en" : "de";
                getSharedPreferences("traj", MODE_PRIVATE).edit().putString("lang", lang).apply();
                // Full restart — applyLocale() will run in new onCreate
                Intent intent = new Intent(this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            })
            .show();
    }

    private String fmtDist(float m) {
        if (m >= 10000) return String.format(Locale.US, "%.1fkm", m / 1000);
        if (m >= 1000) return String.format(Locale.US, "%.2fkm", m / 1000);
        return String.format(Locale.US, "%.1fm", m);
    }

    @Override public void onBackPressed() { if (selectMode) exitSelectMode(); else super.onBackPressed(); }
}
