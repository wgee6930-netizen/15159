#!/bin/bash
# 版本递增脚本 - 每次修改源码后运行
# 用法: bash bump_version.sh [说明]
# 自动将 versionName +0.01, versionCode +1, 编译并复制 APK 到工作区根目录

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MANIFEST="$SCRIPT_DIR/app/src/main/AndroidManifest.xml"

if [ ! -f "$MANIFEST" ]; then
    echo "❌ 找不到 AndroidManifest.xml"
    exit 1
fi

# 读取当前版本
CUR_NAME=$(grep -oP 'versionName="\K[^"]+' "$MANIFEST")
CUR_CODE=$(grep -oP 'versionCode="\K[^"]+' "$MANIFEST")

# 计算新版本: versionName +0.01, versionCode +1
# 处理 3.09 -> 3.10, 3.99 -> 4.00 等进位
MAJOR=$(echo "$CUR_NAME" | cut -d. -f1)
MINOR=$(echo "$CUR_NAME" | cut -d. -f2)
NEW_MINOR=$((MINOR + 1))
NEW_MAJOR=$MAJOR
if [ "$NEW_MINOR" -ge 100 ]; then
    NEW_MINOR=0
    NEW_MAJOR=$((MAJOR + 1))
fi
NEW_NAME="${NEW_MAJOR}.$(printf '%02d' $NEW_MINOR)"
NEW_CODE=$((CUR_CODE + 1))

echo "📦 版本递增: $CUR_NAME ($CUR_CODE) → $NEW_NAME ($NEW_CODE)"

# 更新 Manifest
sed -i "s/android:versionCode=\"$CUR_CODE\"/android:versionCode=\"$NEW_CODE\"/" "$MANIFEST"
sed -i "s/android:versionName=\"$CUR_NAME\"/android:versionName=\"$NEW_NAME\"/" "$MANIFEST"

echo "✅ AndroidManifest.xml 已更新"

# 编译
echo "🔨 开始编译..."
export JAVA_HOME=${JAVA_HOME:-$HOME/jdk-17.0.2}
export ANDROID_HOME=${ANDROID_HOME:-$HOME/android-sdk}
export PATH=$JAVA_HOME/bin:$PATH

bash "$SCRIPT_DIR/build.sh"

# 复制 APK 到工作区根目录
APK="$SCRIPT_DIR/TrajectoryRecorder-v${NEW_NAME}.apk"
if [ -f "$APK" ]; then
    cp "$APK" "$SCRIPT_DIR/../"
    echo "📋 APK 已复制到工作区根目录: TrajectoryRecorder-v${NEW_NAME}.apk"
fi

# 打包源码到工作区根目录
SRC_TAR="$SCRIPT_DIR/../TrajectoryRecorder-v${NEW_NAME}-src.tar.gz"
tar czf "$SRC_TAR" -C "$SCRIPT_DIR" app build.gradle build.sh gradle.properties icon_map2_1024.png settings.gradle bump_version.sh
echo "📋 源码包已打包: TrajectoryRecorder-v${NEW_NAME}-src.tar.gz"

echo ""
echo "=== 版本更新完成 ==="
echo "  版本: $NEW_NAME"
echo "  版本号: $NEW_CODE"
echo "  APK: TrajectoryRecorder-v${NEW_NAME}.apk"
