package com.traj.app;

import android.app.Activity;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Window;

import java.util.Locale;

public abstract class BaseActivity extends Activity {

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        doApplyLocale();
        doApplyBarColors();
    }

    @SuppressWarnings("deprecation")
    @Override
    public Resources getResources() {
        Resources res = super.getResources();
        if (res.getConfiguration().fontScale != 1.0f) {
            Configuration cfg = new Configuration(res.getConfiguration());
            cfg.fontScale = 1.0f;
            res.updateConfiguration(cfg, res.getDisplayMetrics());
        }
        return res;
    }

    @SuppressWarnings("deprecation")
    private void doApplyLocale() {
        String lang = getSharedPreferences("traj", MODE_PRIVATE).getString("lang", "");
        if (lang.isEmpty()) return;
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Resources res = getResources();
        Configuration cfg = res.getConfiguration();
        DisplayMetrics dm = res.getDisplayMetrics();
        cfg.setLocale(locale);
        res.updateConfiguration(cfg, dm);
    }

    private void doApplyBarColors() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#161B22"));
            getWindow().setStatusBarColor(Color.parseColor("#161B22"));
        }
    }

    @Deprecated protected void applyBaseLocale() {}
    @Deprecated protected void applyFullScreen() {}
}
