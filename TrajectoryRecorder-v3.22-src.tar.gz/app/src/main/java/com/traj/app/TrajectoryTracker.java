package com.traj.app;

/**
 * 3D trajectory tracker - stateless continuous integration.
 * Always processes data when sensors available. No fragile flags.
 */
public class TrajectoryTracker {

    // Rotation matrix (device → world), smoothed
    private final float[] R = new float[9];
    private boolean rInit = false;
    private static final float R_ALPHA = 0.15f;

    // Gravity (device frame)
    private float gravX = 0, gravY = 0, gravZ = 0;
    private boolean gravInit = false;

    // Heading fallback (radians)
    private float headingRad = 0;

    // Integration state
    private float velN = 0, velE = 0, velD = 0;
    private float dispN = 0, dispE = 0, dispD = 0;
    private long lastTs = 0;
    private boolean recording = false;

    // ZUPT
    private float zuptMean = 0, zuptVar = 0;
    private int zuptN = 0;
    private static final float ZA = 0.05f, ZT = 0.25f;
    private static final int ZMIN = 50;

    // Smoothing
    private float wN = 0, wE = 0, wD = 0;
    private static final float WA = 0.4f;
    private static final float G = 9.80665f;

    // Steps
    private int steps = 0;
    private float stepDist = 0;
    private long stepTime = 0;

    private float baseAlt = 0;

    // === Control ===

    public void startRecording(float base) {
        this.baseAlt = base;
        recording = true;
        velN = velE = velD = 0;
        dispN = dispE = dispD = 0;
        lastTs = 0;
        wN = wE = wD = 0;
        zuptMean = zuptVar = 0;
        zuptN = 0;
    }

    public void stopRecording() {
        recording = false;
    }

    // === Sensor feeds (always safe to call) ===

    public void feedRotation(float[] m) {
        if (m == null || m.length < 9) return;
        if (!rInit) {
            System.arraycopy(m, 0, R, 0, 9);
            rInit = true;
        } else {
            for (int i = 0; i < 9; i++) R[i] += R_ALPHA * (m[i] - R[i]);
        }
        // Re-orthogonalize
        float l0 = len(R[0], R[1], R[2]);
        if (l0 > 0.01f) { R[0] /= l0; R[1] /= l0; R[2] /= l0; }
        float r1x = R[7]*R[2] - R[8]*R[1];
        float r1y = R[8]*R[0] - R[6]*R[2];
        float r1z = R[6]*R[1] - R[7]*R[0];
        float l1 = len(r1x, r1y, r1z);
        if (l1 > 0.01f) { R[3] = r1x/l1; R[4] = r1y/l1; R[5] = r1z/l1; }
        R[6] = R[1]*R[5] - R[2]*R[4];
        R[7] = R[2]*R[3] - R[0]*R[5];
        R[8] = R[0]*R[4] - R[1]*R[3];
    }

    public void feedHeading(float hRad) {
        this.headingRad = hRad;
        if (!rInit) buildRFromHeading(hRad);
    }

    public void feedGravity(float gx, float gy, float gz) {
        this.gravX = gx; this.gravY = gy; this.gravZ = gz;
        this.gravInit = true;
    }

    public void feedSteps(int s, float d, long t) {
        this.steps = s; this.stepDist = d; this.stepTime = t;
    }

    // === Main integration (call every accel sample) ===

    public void feedAccel(float ax, float ay, float az, long ts) {
        if (!recording || !gravInit) { lastTs = ts; return; }

        float dt = lastTs > 0 ? (ts - lastTs) / 1e9f : 0;
        lastTs = ts;
        if (dt <= 0 || dt > 0.5f) return;

        // Linear accel = raw - gravity
        float lx = ax - gravX;
        float ly = ay - gravY;
        float lz = az - gravZ;

        // To world frame
        float uN, uE, uD;
        if (rInit) {
            uN = R[0]*lx + R[1]*ly + R[2]*lz;
            uE = R[3]*lx + R[4]*ly + R[5]*lz;
            uD = R[6]*lx + R[7]*ly + R[8]*lz;
        } else {
            float cH = (float) Math.cos(headingRad);
            float sH = (float) Math.sin(headingRad);
            uN = lx*cH - ly*sH;
            uE = lx*sH + ly*cH;
            uD = lz;
        }

        // Smooth
        wN += WA * (uN - wN);
        wE += WA * (uE - wE);
        wD += WA * (uD - wD);

        // ZUPT
        float mag = len(lx, ly, lz);
        float d = mag - zuptMean;
        zuptMean += ZA * d;
        zuptVar += ZA * (d*d - zuptVar);
        zuptN++;
        if (zuptN >= ZMIN && zuptVar < ZT) {
            velN = velE = velD = 0;
            zuptN = 0;
            return;
        }

        // Integrate
        velN += wN * dt;
        velE += wE * dt;
        velD += wD * dt;
        dispN += velN * dt;
        dispE += velE * dt;
        dispD += velD * dt;
    }

    // === Queries ===

    public float horizDist() { return len(dispN, dispE, 0); }
    public float vertDisp() { return -dispD; } // positive = up
    public float altitude() { return baseAlt + vertDisp(); }
    public float speed() { return len(velN, velE, velD); }
    public float hSpeed() { return len(velN, velE, 0); }
    public float headingDeg() {
        float h = rInit ? (float) Math.atan2(R[1], R[0]) : headingRad;
        return ((float) Math.toDegrees(h) + 360) % 360;
    }
    public float headingRad() { return rInit ? (float) Math.atan2(R[1], R[0]) : headingRad; }
    public float pitch() { return rInit ? (float) Math.asin(clamp(-R[8], -1, 1)) : 0; }
    public float roll() { return rInit ? (float) Math.atan2(R[5], R[8]) : 0; }
    public float gravNx() { return gravX / G; }
    public float gravNy() { return gravY / G; }
    public float gravNz() { return gravZ / G; }
    public int steps() { return steps; }
    public float stepDist() { return stepDist; }
    public void setBaseAlt(float a) { this.baseAlt = a; }
    public boolean hasData() { return gravInit; }

    // === Helpers ===

    private void buildRFromHeading(float h) {
        float c = (float) Math.cos(h), s = (float) Math.sin(h);
        R[0]=c;  R[1]=-s; R[2]=0;
        R[3]=s;  R[4]=c;  R[5]=0;
        R[6]=0;  R[7]=0;  R[8]=1;
        rInit = true;
    }

    private static float len(float x, float y, float z) {
        return (float) Math.sqrt(x*x + y*y + z*z);
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
