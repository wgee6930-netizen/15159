package com.traj.app;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;

public class RecordSettingsActivity extends BaseActivity {
    private SharedPreferences prefs;
    private RadioGroup rgPrecision;
    private RadioButton rb01, rb05, rb1;
    private Switch swGps;
    private EditText etBaseAlt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyBaseLocale();
        applyFullScreen();
        setContentView(R.layout.activity_record_settings);

        prefs = getSharedPreferences("traj", MODE_PRIVATE);

        rgPrecision = findViewById(R.id.rgPrecision);
        rb01 = findViewById(R.id.rbPrec01);
        rb05 = findViewById(R.id.rbPrec05);
        rb1 = findViewById(R.id.rbPrec1);
        swGps = findViewById(R.id.swGps);
        etBaseAlt = findViewById(R.id.etBaseAlt);

        int prec = prefs.getInt("precision", 0);
        switch (prec) {
            case 0: rb01.setChecked(true); break;
            case 1: rb05.setChecked(true); break;
            case 2: rb1.setChecked(true); break;
        }
        swGps.setChecked(prefs.getBoolean("gps", false));
        float baseAlt = prefs.getFloat("baseAlt", 0);
        if (baseAlt != 0) etBaseAlt.setText(String.valueOf(baseAlt));

        findViewById(R.id.btnBack).setOnClickListener(v -> saveAndFinish());
    }

    private void saveAndFinish() {
        SharedPreferences.Editor ed = prefs.edit();
        int prec = 0;
        if (rb05.isChecked()) prec = 1;
        else if (rb1.isChecked()) prec = 2;
        ed.putInt("precision", prec);
        ed.putBoolean("gps", swGps.isChecked());
        try {
            float alt = Float.parseFloat(etBaseAlt.getText().toString());
            ed.putFloat("baseAlt", alt);
        } catch (NumberFormatException e) {
            ed.putFloat("baseAlt", 0);
        }
        ed.apply();
        finish();
    }

    @Override
    public void onBackPressed() {
        saveAndFinish();
    }
}
