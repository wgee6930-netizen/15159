package com.traj.app;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;

/**
 * 传感器融合管理器
 * - 加速度计 + 陀螺仪 → 航向/姿态
 * - 步态检测 → 动态步长估算
 * - 气压计 → 相对海拔
 */
public class SensorFusionManager implements SensorEventListener {

    public interface FusionCallback {
        void onOrientationUpdate(float heading, float pitch, float roll);
        void onStepUpdate(int steps, float distance, float stepLength);
        void onBarometerUpdate(float pressureHpa, float altitudeM);
        void onAccuracyChanged(int accuracy);
    }

    private final SensorManager sm;
    private Sensor accel, gyro, baro, stepCounter;
    private FusionCallback callback;
    private HandlerThread sensorThread;
    private Handler sensorHandler;

    // 陀螺仪积分
    private float[] gyroAngle = {0, 0, 0};
    private long lastGyroTime = 0;
    private boolean gyroInitialized = false;

    // 互补滤波
    private float compHeading = 0, compPitch = 0, compRoll = 0;
    private static final float ALPHA = 0.98f; // 陀螺仪权重

    // 步态检测
    private float[] gravity = new float[3];
    private float[] linearAccel = new float[3];
    private boolean gravityReady = false;
    private float filteredAccelMag = 0;
    private boolean lastPeak = false;
    private long lastStepTime = 0;
    private int totalSteps = 0;
    private float totalDistance = 0;
    private float lastStepLength = 0.72f;
    private float userHeight = 1.70f;

    // 步频估算
    private long[] stepTimes = new long[8];
    private int stepTimeIdx = 0;
    private float stepFrequency = 0;

    // 加速度方差（动态步长用）
    private float accelVariance = 0;
    private float accelMean = 0;
    private int accelSampleCount = 0;
    private static final int VARIANCE_WINDOW = 50;

    // 气压计
    private float lastPressure = 0;
    private float pressureAltitude = 0;
    private boolean baroAvailable = false;

    // 低通滤波
    private static final float LPF_ALPHA = 0.2f;
    private boolean running = false;

    public SensorFusionManager(Context ctx) {
        sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        baro = sm.getDefaultSensor(Sensor.TYPE_PRESSURE);
        stepCounter = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        // 默认值
        if (baro != null) baroAvailable = true;
    }

    public void start(FusionCallback cb) {
        if (running) return;
        running = true;
        callback = cb;

        sensorThread = new HandlerThread("SensorFusion");
        sensorThread.start();
        sensorHandler = new Handler(sensorThread.getLooper());

        gyroInitialized = false;
        lastGyroTime = 0;

        if (accel != null) {
            sm.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME, sensorHandler);
        }
        if (gyro != null) {
            sm.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME, sensorHandler);
        }
        if (baro != null) {
            sm.registerListener(this, baro, SensorManager.SENSOR_DELAY_UI, sensorHandler);
        }
        // TYPE_STEP_COUNTER 是硬件计步器，精度高但不是所有设备都有
        if (stepCounter != null) {
            sm.registerListener(this, stepCounter, SensorManager.SENSOR_DELAY_UI, sensorHandler);
        }
    }

    public void stop() {
        if (!running) return;
        running = false;
        sm.unregisterListener(this);
        if (sensorThread != null) {
            sensorThread.quitSafely();
            sensorThread = null;
            sensorHandler = null;
        }
    }

    public void setUserHeight(float h) { userHeight = h; }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!running) return;
        switch (event.sensor.getType()) {
            case Sensor.TYPE_ACCELEROMETER:
                processAccel(event);
                break;
            case Sensor.TYPE_GYROSCOPE:
                processGyro(event);
                break;
            case Sensor.TYPE_PRESSURE:
                processBaro(event);
                break;
            case Sensor.TYPE_STEP_COUNTER:
                processHardwareStep(event);
                break;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        if (callback != null) callback.onAccuracyChanged(accuracy);
    }

    // === 加速度计处理 ===
    private void processAccel(SensorEvent e) {
        // 分离重力
        final float g = 0.8f;
        gravity[0] = g * gravity[0] + (1 - g) * e.values[0];
        gravity[1] = g * gravity[1] + (1 - g) * e.values[1];
        gravity[2] = g * gravity[2] + (1 - g) * e.values[2];

        linearAccel[0] = e.values[0] - gravity[0];
        linearAccel[1] = e.values[1] - gravity[1];
        linearAccel[2] = e.values[2] - gravity[2];

        if (!gravityReady) {
            // 初始姿态
            float ax = gravity[0], ay = gravity[1], az = gravity[2];
            compPitch = (float) Math.atan2(ax, Math.sqrt(ay * ay + az * az));
            compRoll = (float) Math.atan2(ay, az);
            gravityReady = true;
            return;
        }

        // 步态检测（无硬件计步器时启用）
        if (stepCounter == null) {
            detectStep(e);
        }

        // 更新加速度方差（用于动态步长）
        float mag = (float) Math.sqrt(
            linearAccel[0] * linearAccel[0] +
            linearAccel[1] * linearAccel[1] +
            linearAccel[2] * linearAccel[2]);
        updateAccelVariance(mag);
    }

    // === 陀螺仪处理 ===
    private void processGyro(SensorEvent e) {
        long now = SystemClock.elapsedRealtimeNanos();
        if (lastGyroTime == 0) { lastGyroTime = now; return; }
        float dt = (now - lastGyroTime) / 1e9f;
        lastGyroTime = now;
        if (dt > 0.1f) return; // 丢帧保护

        // 积分
        gyroAngle[0] += e.values[0] * dt;
        gyroAngle[1] += e.values[1] * dt;
        gyroAngle[2] += e.values[2] * dt;

        if (!gyroInitialized) {
            gyroInitialized = true;
            gyroAngle[0] = compHeading;
            gyroAngle[1] = compPitch;
            gyroAngle[2] = compRoll;
        }

        // 互补滤波
        // 加速度计提供 pitch/roll 的绝对参考
        if (gravityReady) {
            float accPitch = (float) Math.atan2(gravity[0],
                Math.sqrt(gravity[1] * gravity[1] + gravity[2] * gravity[2]));
            float accRoll = (float) Math.atan2(gravity[1], gravity[2]);

            compPitch = ALPHA * gyroAngle[1] + (1 - ALPHA) * accPitch;
            compRoll = ALPHA * gyroAngle[2] + (1 - ALPHA) * accRoll;
        }
        // 航向用纯陀螺仪积分（磁力计不可靠）
        compHeading = normalizeAngle(gyroAngle[0]);

        if (callback != null) {
            callback.onOrientationUpdate(
                (float) Math.toDegrees(compHeading),
                (float) Math.toDegrees(compPitch),
                (float) Math.toDegrees(compRoll));
        }
    }

    // === 气压计处理 ===
    private void processBaro(SensorEvent e) {
        lastPressure = e.values[0]; // hPa
        // 国际标准大气公式
        pressureAltitude = 44330f * (1 - (float) Math.pow(lastPressure / 1013.25, 1.0 / 5.255));
        if (callback != null) {
            callback.onBarometerUpdate(lastPressure, pressureAltitude);
        }
    }

    // === 硬件计步器 ===
    private void processHardwareStep(SensorEvent e) {
        int hwSteps = (int) e.values[0];
        if (totalSteps == 0) {
            totalSteps = hwSteps;
            return;
        }
        int delta = hwSteps - totalSteps;
        if (delta > 0 && delta < 100) { // 合理性检查
            for (int i = 0; i < delta; i++) {
                float sl = estimateStepLength();
                totalDistance += sl;
                totalSteps++;
                lastStepLength = sl;
            }
            if (callback != null) {
                callback.onStepUpdate(totalSteps, totalDistance, lastStepLength);
            }
        }
        totalSteps = hwSteps;
    }

    // === 步态检测（无硬件计步器时） ===
    private void detectStep(SensorEvent e) {
        float mag = (float) Math.sqrt(
            linearAccel[0] * linearAccel[0] +
            linearAccel[1] * linearAccel[1] +
            linearAccel[2] * linearAccel[2]);

        // 低通滤波
        filteredAccelMag = filteredAccelMag * 0.7f + mag * 0.3f;

        long now = SystemClock.elapsedRealtime();
        boolean isPeak = filteredAccelMag > 1.5f;

        // 上升沿检测 + 冷却
        if (isPeak && !lastPeak && (now - lastStepTime) > 250) {
            lastStepTime = now;
            float sl = estimateStepLength();
            totalDistance += sl;
            totalSteps++;
            lastStepLength = sl;

            // 步频计算
            stepTimes[stepTimeIdx % 8] = now;
            stepTimeIdx++;
            if (stepTimeIdx >= 2) {
                int count = Math.min(stepTimeIdx, 8);
                long span = stepTimes[(stepTimeIdx - 1) % 8] - stepTimes[Math.max(0, stepTimeIdx - count) % 8];
                if (span > 0) stepFrequency = (count - 1) * 1000f / span;
            }

            if (callback != null) {
                callback.onStepUpdate(totalSteps, totalDistance, lastStepLength);
            }
        }
        lastPeak = isPeak;
    }

    // === 动态步长估算 ===
    // Weinberg model + 加速度方差修正
    private float estimateStepLength() {
        float base = 0.4f * (float) Math.sqrt(Math.abs(accelVariance));
        base = Math.max(0.4f, Math.min(1.2f, base));

        // 身高修正
        float heightFactor = userHeight / 1.70f;
        base *= heightFactor;

        // 步频修正（快走步幅更大）
        if (stepFrequency > 1.2f) {
            base *= 1.0f + (stepFrequency - 1.2f) * 0.15f;
        }
        return Math.max(0.3f, Math.min(1.3f, base));
    }

    private void updateAccelVariance(float sample) {
        accelSampleCount++;
        float delta = sample - accelMean;
        accelMean += delta / Math.min(accelSampleCount, VARIANCE_WINDOW);
        accelVariance += (delta * (sample - accelMean) - accelVariance) / Math.min(accelSampleCount, VARIANCE_WINDOW);
        if (accelSampleCount > VARIANCE_WINDOW * 2) {
            accelSampleCount = VARIANCE_WINDOW; // 滚动窗口
        }
    }

    private float normalizeAngle(float a) {
        while (a > Math.PI) a -= 2 * Math.PI;
        while (a < -Math.PI) a += 2 * Math.PI;
        return a;
    }

    // === 公开接口 ===
    public float getHeadingDeg() { return (float) Math.toDegrees(compHeading); }
    public float getPitchDeg() { return (float) Math.toDegrees(compPitch); }
    public float getRollDeg() { return (float) Math.toDegrees(compRoll); }
    public int getTotalSteps() { return totalSteps; }
    public float getTotalDistance() { return totalDistance; }
    public float getLastStepLength() { return lastStepLength; }
    public float getStepFrequency() { return stepFrequency; }
    public float getPressureHpa() { return lastPressure; }
    public boolean isBaroAvailable() { return baroAvailable; }
    public boolean isGyroAvailable() { return gyro != null; }
    public boolean isStepCounterAvailable() { return stepCounter != null; }

    public void reset() {
        totalSteps = 0;
        totalDistance = 0;
        lastStepLength = 0.72f;
        stepFrequency = 0;
        stepTimeIdx = 0;
        filteredAccelMag = 0;
        accelVariance = 0;
        accelMean = 0;
        accelSampleCount = 0;
        gyroAngle = new float[]{0, 0, 0};
        compHeading = 0;
        compPitch = 0;
        compRoll = 0;
        gravityReady = false;
        gyroInitialized = false;
        lastGyroTime = 0;
    }
}
