#!/bin/bash
set -e

ANDROID_HOME=${ANDROID_HOME:-$HOME/android-sdk}
BT=$ANDROID_HOME/build-tools/34.0.0
PL=$ANDROID_HOME/platforms/android-34/android.jar
D=$(cd "$(dirname "$0")" && pwd)
S=$D/app/src/main
O=$D/build

# === 图标 ===
echo "=== 0. 处理图标 ==="
ICON_SRC=""
for f in $D/0000/1/icon_map2_1024.png /vol1/thumb/1000/list/1/icon_map2_1024.png; do
  [ -f "$f" ] && ICON_SRC="$f" && break
done
if [ -n "$ICON_SRC" ]; then
  echo "  源图标: $ICON_SRC"
  ffmpeg -y -i "$ICON_SRC" -s 48x48   $S/res/mipmap-mdpi/ic_launcher.png   2>/dev/null
  ffmpeg -y -i "$ICON_SRC" -s 72x72   $S/res/mipmap-hdpi/ic_launcher.png   2>/dev/null
  ffmpeg -y -i "$ICON_SRC" -s 96x96   $S/res/mipmap-xhdpi/ic_launcher.png  2>/dev/null
  ffmpeg -y -i "$ICON_SRC" -s 144x144 $S/res/mipmap-xxhdpi/ic_launcher.png 2>/dev/null
  ffmpeg -y -i "$ICON_SRC" -s 192x192 $S/res/mipmap-xxxhdpi/ic_launcher.png 2>/dev/null
  echo "  图标已生成"
else
  echo "  ⚠ 未找到图标文件，使用默认"
fi

# === 版本同步 ===
echo "=== 版本同步 ==="
VER=$(grep -oP 'versionName="\K[^"]+' $S/AndroidManifest.xml)
echo "  版本: $VER"

# 编译
echo "=== 1. aapt2 compile ==="
rm -rf $O && mkdir -p $O/gen $O/obj $O/dex $O/apk
$BT/aapt2 compile --dir $S/res -o $O/resources.zip

echo "=== 2. aapt2 link ==="
$BT/aapt2 link -o $O/apk/app.unsigned.apk -I $PL \
  --manifest $S/AndroidManifest.xml --java $O/gen \
  -A $S/assets --auto-add-overlay $O/resources.zip

echo "=== 3. javac ==="
javac -classpath $PL -d $O/obj \
  $O/gen/com/traj/app/R.java \
  $S/java/com/traj/app/MainActivity.java \
  $S/java/com/traj/app/LocationService.java

echo "=== 4. d8 ==="
$BT/d8 --output $O/dex --lib $PL $O/obj/com/traj/app/*.class

echo "=== 5. 打包 ==="
cd $O/apk && cp app.unsigned.apk app.tmp.apk
zip -j app.tmp.apk $O/dex/classes.dex

echo "=== 6. zipalign ==="
$BT/zipalign -f 4 app.tmp.apk app.aligned.apk

echo "=== 7. 签名 ==="
KS=$D/app/release.keystore
[ ! -f "$KS" ] && [ -f ~/release.keystore ] && cp ~/release.keystore $KS
[ ! -f "$KS" ] && keytool -genkey -v -keystore $KS -alias release \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass 123456 -keypass 123456 \
  -dname "CN=Traj,OU=Dev,O=Home,L=SH,ST=SH,C=CN"
$BT/apksigner sign --ks $KS --ks-pass pass:123456 \
  --key-pass pass:123456 --ks-key-alias release \
  --out $D/TrajectoryRecorder-v${VER}.apk app.aligned.apk

echo ""
echo "=== ✅ 完成 ==="
ls -lh $D/TrajectoryRecorder-v${VER}.apk
